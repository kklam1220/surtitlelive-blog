# QLab subtitles i18n draft pack

Slug: `13-quick-qlab-subtitles-from-excel-txt`

This pack contains 17 draft localization JSON payloads in the repo's existing structure:

`src/content/i18n/blog/<locale>/13-quick-qlab-subtitles-from-excel-txt.json`

Locales:
ar, de, es, fr, id, it, ja, ko, pl, pt, ru, th, tr, uk, vi, zh-CN, zh-TW

Important:
- These are AI draft translations/localizations, not native-reviewed final copy.
- Status is `translated_draft`, not `translated`, so you can review before publishing.
- Code blocks, QLab property names, URLs, and product names are preserved.
- The `sourceHash` is a stable draft hash generated in this pack; run the repo's normal i18n sync/check flow before merge if exact source-hash alignment is required.
