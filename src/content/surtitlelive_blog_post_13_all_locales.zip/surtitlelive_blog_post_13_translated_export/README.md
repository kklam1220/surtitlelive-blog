# SurtitleLive Blog Post 13 — Translated Export Script Article

Prepared files for the blog post:

- English source: `src/content/blog/13-export-translated-play-script-international-submission.md`
- Localized JSON payloads: `src/content/i18n/blog/<locale>/13-export-translated-play-script-international-submission.json`
- Human-review Markdown copies: `review-markdown/<locale>.md`

Slug: `13-export-translated-play-script-international-submission`
Source hash in localized JSON: `1c2bc2a924cc550529d931707b02a8cf1cee06a0a250c7c81070d6a294b2c8a5`

Locales included:
ar, de, es, fr, id, it, ja, ko, pl, pt, ru, th, tr, uk, vi, zh-CN, zh-TW

Notes:
- `zh-TW` keeps the Traditional Chinese translation approved in the conversation.
- The English source and localized JSON bodies omit a duplicate top-level H1 because the blog layout normally renders the frontmatter title.
- The localized JSON structure follows the existing blog i18n payload shape: version, locale, sourceLocale, slug, sourcePath, sourceHash, status, timestamps, frontmatter, and body.
- Final native-language review is still recommended before publishing, especially for legal/rights wording and region-specific theatre terminology.
