---
title: 'Uluslararası Başvuru için Biçimlendirilmiş Çevrilmiş Bir Oyun Metni Nasıl Hazırlanır ve Dışa Aktarılır'
description: 'Festivaller, yurt dışındaki yapımcılar, ortak yapımlar ve uluslararası tiyatro iş birlikleri için çevrilmiş ve biçimlendirilmiş bir oyun metnini nasıl hazırlayıp gözden geçirerek dışa aktaracağınızı öğrenin.'
pubDate: '2026-06-29'
heroImage: './export-translated-play-script-international-submission.png'
heroImageAlt: 'Uluslararası tiyatro başvurusu için hazırlanmış biçimlendirilmiş çevrilmiş oyun metni'
tags: ['Oyun Çevirisi', 'Tiyatro Çevirisi', 'Metin Dışa Aktarma', 'Uluslararası Tiyatro', 'SurtitleLive']
---

**Temel Özet:**  
Çevrilmiş bir oyun metni, uluslararası başvuru için ancak okunabilir, yapılandırılmış ve açık biçimde formatlanmışsa gerçekten işe yarar. Çeviri ilk adımdır; fakat tiyatro ekiplerinin karakter adlarını, diyalog bloklarını, sahne yönergelerini, sahne yapısını ve sürüm etiketlerini de koruması gerekir. SurtitleLive, ekiplerin özgün Word metninden gözden geçirilmiş çevirilere ilerlemesine ve ardından festivaller, yurt dışındaki yapımcılar, çevirmenler, dramaturglar veya ortak yapım ortaklarıyla paylaşılabilecek biçimlendirilmiş bir çevrilmiş metin dışa aktarmasına yardımcı olur.

Birçok oyun yazarı ve tiyatro topluluğu, bir oyunu yurt dışına göndermenin en zor kısmının çeviri olduğunu düşünür.

Çeviri zordur; fakat sorunun yalnızca yarısıdır.

Kelimeler çevrildikten sonra birinin metni hâlâ yeniden kurması gerekir. Karakter adları tutarlı kalmalıdır. Diyalog okunabilir olmalıdır. Sahne yönergeleri konuşulan repliklerle karıştırılmamalıdır. Sahne geçişleri korunmalıdır. Son dosya, kopyalanmış makine çevirisi çıktısı değil, bir oyun metni gibi görünmelidir.

SurtitleLive’ın azaltmak için tasarlandığı iş akışı sorunu budur.

SurtitleLive, çeviriyi birbirinden kopuk metin parçaları olarak ele almak yerine oyunu yapılandırılmış bir tiyatro belgesi olarak korur. Ekip çevrilmiş satırları gözden geçirebilir, dili inceltebilir ve ardından uluslararası okurlar için biçimlendirilmiş bir çevrilmiş oyun metni dışa aktarabilir.

Yurt dışı başvuruları, festivaller, rezidanslar, turne görüşmeleri veya ortak yapımlar hazırlayan oyun yazarları, yapımcılar, çevirmenler ve tiyatro toplulukları için bu, çeviriyi dağınık bir kopyala-yapıştır sürecinden daha temiz bir üretim iş akışına dönüştürebilir.

## Çeviri yalnızca ilk adımdır

Bir oyun metni, kelimeleri başka bir dile çevrildi diye bitmiş sayılmaz.

Bir tiyatro metninin yapısı vardır:

- karakter adları
- diyalog
- sahne yönergeleri
- perde ve sahne bölümleri
- üretim notları
- şarkılar veya şiirsel bölümler
- yinelenen ifadeler
- duraklamalar, sessizlik ve ritim
- okurun neyin söylendiğini, neyin söylenmediğini anlamasına yardımcı olan biçim gelenekleri

Bir metin genel bir çeviri aracına kopyalandığında, bu yapının büyük bölümü kaybolabilir.

Sonuç çevrilmiş metin içerebilir, ama kullanılabilir bir çevrilmiş oyun metni olmayabilir.

Örneğin makine çevirisi uzun bir metin bloğu verebilir. Karakter adlarını tutarsız çevirebilir. Sahne yönergelerini diyalogla birleştirebilir. Önemli satır sonlarını silebilir. Anlamı kavramaya yardımcı olabilir, ama dosya başka bir tiyatroya gönderilmeden önce hâlâ saatler süren elle biçimlendirme işi bırakabilir.

Uluslararası başvuruda sunum önemlidir.

Bir festival okuru, yabancı yapımcı, dramaturg veya ortak yapım partneri, metninizi okumadan önce onu yeniden kurmak zorunda kalmamalıdır. Oyunun yapısını açıkça gösteren temiz bir belgeye ihtiyaç duyarlar.

Bu yüzden dışa aktarma aşaması önemlidir.

## Biçimlendirilmiş çevrilmiş bir metin uluslararası tiyatroda neden önemlidir?

Bir oyunu başka bir ülkeye veya bölgeye gönderdiğinizde, çevrilmiş metin çoğu zaman çalışmanız ile yeni bir sanat topluluğu arasındaki ilk köprü olur.

Okur sizin dilinizi, tiyatro çevrenizi, kültürel bağlamınızı veya özgün sahneleme tarzınızı bilmiyor olabilir. Çevrilmiş metin, eseri sahnede hayal edebilecek kadar net anlamasına yardımcı olmalıdır.

Biçimlendirilmiş bir çevrilmiş metin şu durumlarda yardımcı olur:

| Kullanım | Biçim neden önemlidir |
| --- | --- |
| Festival başvurusu | Okurlar hikâyeyi, karakterleri ve sahne akışını karışıklık yaşamadan takip eder |
| Yurt dışı yapımcı incelemesi | Yapımcılar eserin sezonlarına, mekânlarına veya seyircilerine uygun olup olmadığını değerlendirebilir |
| Ortak yapım görüşmesi | Partnerler aynı sahneleri, satırları ve karakterleri daha kesin biçimde tartışabilir |
| Çeviri incelemesi | Çevirmenler ve dramaturglar kaynak ve hedef metni daha kolay karşılaştırabilir |
| Rezidans veya hibe başvurusu | Kurullar oyunu tutarlı bir tiyatro belgesi olarak okuyabilir |
| Prova planlaması | Yönetmenler ve oyuncular kimin, ne zaman, hangi bağlamda konuştuğunu anlayabilir |
| Gelecekteki surtitles veya captions | Yapılandırılmış çevrilmiş metin daha sonra canlı cue metnine uyarlanabilir |

Biçimlendirilmiş bir çevrilmiş metin, ham çeviri çıktısından sadece daha güzel değildir. Daha kullanışlıdır.

Okura şunları gösterir:

- kimin konuştuğunu
- neyin sahne yönergesi olduğunu
- sahnenin nerede değiştiğini
- diyaloğun nasıl aktığını
- çevirinin taslak mı, başvuru sürümü mü, gözden geçirilmiş sürüm mü olduğunu
- çevrilmiş metnin özgün metinle nasıl ilişkili olduğunu

Uluslararası tiyatroda bu açıklık, bir oyunun anlaşılması ile bir kenara bırakılması arasındaki fark olabilir.

## Çeviri sonrası kopyala-yapıştır sorunu

Birçok ekip oyun çevirisini hâlâ manuel bir süreçle yürütür:

1. Özgün metnin bir bölümünü kopyalar.
2. Bir çeviri aracına yapıştırır.
3. Çevrilmiş çıktıyı kopyalar.
4. Yeni bir belgeye yapıştırır.
5. Karakter adlarını yeniden kurar.
6. Satır sonlarını yeniden kurar.
7. Sahne yönergelerini düzeltir.
8. Biçimi onarır.
9. Tüm metin bitene kadar tekrarlar.

Bu birkaç sayfa için çalışabilir.

Tam uzunlukta bir oyun için acı verici hale gelir.

Ayrıca risk yaratır. Ekip yanlışlıkla bir satırı düşürebilir, bir satırı iki kez ekleyebilir, konuşanı yanlış etiketleyebilir, bir sahne yönergesini kaybedebilir veya metin değiştikten sonra eski sürümü gönderebilir.

Sorun yalnızca çeviri kalitesi değildir. Sorun belge kontrolüdür.

Kaynak metin, çevrilmiş satırlar, revizyonlar ve nihai dışa aktarma ayrı dosyalarda yaşıyorsa ekip tutarlılığı elle yönetmek zorundadır. Oyun yazarı, çevirmen, yönetmen, dramaturg, yapımcı veya yurt dışı partneri gibi birden fazla kişi dahil olduğunda bu daha da zorlaşır.

SurtitleLive farklı bir fikir üzerine kuruludur:

> Metni baştan itibaren yapılandırılmış tutun, çevirileri bu yapının içinde gözden geçirin ve çevrilmiş sürümü aynı iş akışından dışa aktarın.

## SurtitleLive iş akışı: özgün metinden biçimlendirilmiş çeviri dışa aktarımına

SurtitleLive, uluslararası kullanım için çevrilmiş metinlere ihtiyaç duyan tiyatro ekipleri için script-first bir iş akışını destekler.

Süreç şöyle görünebilir.

### 1. Özgün Word metnini yükleyin

Özgün metinle başlayın; ideal olarak temiz bir Word `.docx` dosyasıyla.

Word metni, tiyatro düzenine ait önemli işaretleri koruyabilir: paragraf sonları, girintiler, konuşan etiketleri, italikler ve diyaloğu sahne yönergesinden ayırmaya yardımcı olan diğer biçimler.

SurtitleLive, yüklenen metnin yapısını iş akışının temeli olarak kullanır.

### 2. Algılanan metin yapısını gözden geçirin

Yüklemeden sonra ekip metin yapısını gözden geçirir.

Buna şunlar dahil olabilir:

- konuşan veya karakter adları
- diyalog satırları
- sahne yönergeleri
- sahne veya perde bölümleri
- karakter rolleri
- elle düzeltilmesi gereken satırlar

Bu adım önemlidir, çünkü sistem her satırın ne olduğunu bildiğinde çeviri daha kolay yönetilir.

Bir karakter repliği, bir sahne yönergesi ve bir başlık aynı şekilde ele alınmamalıdır.

### 3. Çevrilmiş metni oluşturun veya girin

Kaynak metin yapılandırıldıktan sonra ekip çevrilmiş metni oluşturabilir.

Prodüksiyonun ihtiyaçlarına bağlı olarak bu şunları içerebilir:

- AI-assisted translation drafts
- insan çevirmen girdisi
- düzenlenmiş iki dilli taslaklar
- satır satır yapıştırılan mevcut çeviriler
- çevirmen tarafından gözden geçirilmiş sürümler
- dile özel çalışma taslakları

Önemli nokta, çevirilerin özgün metin satırlarına bağlı kalmasıdır.

Bu incelemeyi kolaylaştırır. Dışa aktarmayı da daha temiz hale getirir.

### 4. Çeviriyi satır satır gözden geçirin

Dışa aktarmadan önce çevrilmiş metin bir insan tarafından gözden geçirilmelidir.

Bu tiyatroda özellikle önemlidir, çünkü doğru çeviri her zaman en kelimesi kelimesine çeviri değildir.

Gözden geçirenler şunları kontrol edebilir:

- karakter sesi
- ritim
- alt metin
- kültürel göndermeler
- şakalar ve deyimler
- duygusal baskı
- satır uzunluğu
- sahne açıklığı
- ad ve terim tutarlılığı

SurtitleLive bu incelemeyi metin iş akışının içinde tutmaya yardımcı olur; ekipleri kopuk belgeleri karşılaştırmaya zorlamaz.

### 5. Çevrilmiş metin dışa aktarımını seçin

Çeviri gözden geçirildikten sonra ekip biçimlendirilmiş çevrilmiş bir oyun metni dışa aktarabilir.

Bu uluslararası başvuru için kilit adımdır.

Ham çeviri tablosu veya dağınık kopyalanmış belge göndermek yerine ekip, tiyatro yapısını koruyan okunabilir bir metin sürümü yaratabilir.

Biçimlendirilmiş çeviri dışa aktarımı şu amaçlarla kullanılabilir:

- festival başvuruları
- yabancı yapımcılar için okuma kopyaları
- ortak yapım görüşmeleri
- çevirmen veya dramaturg incelemesi
- prova planlaması
- partner iletişimi
- erken turne görüşmeleri
- gelecekte surtitles veya captions hazırlığı

Dışa aktarma sadece bir dosya değildir. Bir devir belgesidir.

## Biçimlendirilmiş çevrilmiş bir oyun metni neleri içermeli?

Kullanışlı bir çevrilmiş metin, okuma deneyimini netleştirmelidir.

Başvuru veya iş birliği bağlamına göre şunları içerebilir:

- çevrilmiş başlık
- yararlıysa özgün başlık
- yazar adı
- çevirmen veya taslak durumu
- “English submission draft” gibi sürüm etiketi
- karakter listesi
- perde ve sahne yapısı
- konuşan adları
- çevrilmiş diyalog
- çevrilmiş sahne yönergeleri
- tutarlı satır aralığı
- diyalog ile yönergelerin açık ayrımı
- kültüre özgü terimler için isteğe bağlı notlar
- uygun olduğunda iletişim veya hak bilgisi

Uluslararası başvuru için sürüm etiketleri özellikle önemlidir.

Okur şunu bilmelidir:

- makine destekli ilk taslak mı
- oyun yazarı tarafından gözden geçirilmiş başvuru taslağı mı
- çevirmen tarafından gözden geçirilmiş metin mi
- kelimesi kelimesine referans çevirisi mi
- prova taslağı mı
- performans adaptasyonu mu
- surtitle veya caption taslağı mı

Bunlar farklı belge türleridir. Açık etiketleme eseri yanlış anlaşılmaktan korur.

## Örnek: Kantonca özgün metinden İngilizce başvuru taslağına

Hong Konglu bir oyun yazarının Kantonca bir oyunu Kanada’daki bir tiyatro festivaline göndermek istediğini düşünün.

Özgün metin Kantonca yazılmıştır. Hikâye Hong Kong aile yaşamına özgüdür. Mizah ritme, ilişkilere ve kültürel ayrıntıya bağlıdır. Ancak festival okuru, eserin programa uygun olup olmadığına karar vermeden önce İngilizce bir sürüme ihtiyaç duyar.

Pratik bir SurtitleLive iş akışı şöyle olabilir:

1. Oyun yazarı özgün Kantonca Word metnini yükler.
2. SurtitleLive konuşanları, diyaloğu ve sahne yönergelerini belirlemeye yardımcı olur.
3. Ekip metin yapısını gözden geçirir.
4. İngilizce çeviri taslağı oluşturulur.
5. Oyun yazarı veya çevirmen İngilizceyi satır satır düzenler.
6. Karakter adları, kültürel terimler ve duygusal satırlar dikkatle kontrol edilir.
7. Ekip biçimlendirilmiş İngilizce başvuru taslağını dışa aktarır.
8. Dosya, çeviri durumunu açıklayan net bir notla festivale gönderilir.
9. Proje ilerlerse aynı yapılandırılmış metin daha sonra prova çevirisi, surtitles, captions, projection veya mobile audience viewing için kullanılabilir.

Bu workflow yazılımın sanatsal yargının yerini alabileceğini iddia etmez.

Başka bir problemi çözer: ekibin özgün metinden, çeviri sonrası metni elle yeniden kurmadan gözden geçirilmiş çevrilmiş belgeye ilerlemesine yardımcı olur.

## Örnek: İspanyolca oyundan Almanca ortak yapım taslağına

Şimdi bir İspanyol tiyatro topluluğunun Alman bir mekânla ortak yapım görüşmesi hazırladığını düşünün.

Alman partnerin henüz yayıma hazır nihai edebi çeviriye ihtiyacı yoktur. Hikâyeyi anlamak, üretim ölçeğini tartışmak ve projenin geliştirmeye değer olup olmadığına karar vermek için okunabilir bir çalışma taslağına ihtiyaç duyar.

Bu durumda çevrilmiş dışa aktarım final performans sürümü olmak zorunda değildir.

Şunlara sahip olmalıdır:

- okunabilir
- yapılandırılmış
- açıkça etiketlenmiş
- tartışması kolay
- sanatsal konuşma için özgüne yeterince yakın
- sonraki çeviri incelemesi için düzenlenebilir

Topluluk İspanyolca kaynak metni hazırlayabilir, Almanca çeviri üretebilir veya girebilir, kilit sahneleri gözden geçirebilir ve partner için biçimlendirilmiş Almanca çalışma taslağı dışa aktarabilir.

Daha sonra proje provaya veya prodüksiyona girerse çeviri metni daha da geliştirilebilir.

Dışa aktarma konuşmanın daha erken başlamasına yardımcı olur.

## Dışa aktarma insan incelemesinin yerine geçmez

Biçimlendirilmiş çevrilmiş metin güçlüdür, ama çevirinin sanatsal olarak nihai olduğunu garanti etmez.

Ciddi tiyatro işinde insan incelemesi hâlâ önemlidir.

Dışa aktarılan metni önemli başvuru, yayın, lisans veya prodüksiyon için kullanmadan önce ekip şu kişiler tarafından inceleme düşünmelidir:

- oyun yazarı
- profesyonel çevirmen
- dramaturg
- yönetmen
- hedef dilin ana dili konuşanı
- gerekiyorsa hak sahibi veya yayınevi

SurtitleLive yapı, çeviri workflow’u, inceleme ve dışa aktarma konusunda yardımcı olur. Çevrilmiş metni yeniden kurma mekanik yükünü azaltır. Sanatsal, hukuki veya kültürel yargı sorumluluğunu ortadan kaldırmaz.

Bu ayrım önemlidir.

Amaç tiyatro çevirisini otomatik yapmak değildir.

Amaç workflow’u daha az kırılgan hâle getirmektir.

## İki dilli metin mi, yalnızca çevrilmiş metin mi?

Uluslararası iş birliklerinde ekipler sık sık iki dilli metin mi yoksa yalnızca çevrilmiş metin mi göndermeleri gerektiğini sorar.

Cevap okura bağlıdır.

Festival okuru, özellikle kaynak dili okumuyorsa, temiz bir yalnızca çeviri sürümünü tercih edebilir.

Çevirmen veya dramaturg, kaynak ve hedef satırları karşılaştırabilmek için iki dilli sürümü tercih edebilir.

Ortak yapım partneri ikisini de isteyebilir: genel konuşma için temiz bir çevrilmiş okuma taslağı ve daha derin inceleme için iki dilli çalışma sürümü.

Dışa aktarmaya hazırlanırken sorun:

- Bu dosyayı kim okuyacak?
- Özgün dili anlıyorlar mı?
- Hikâyeyi mi değerlendiriyorlar, çeviri doğruluğunu mu?
- Bu başvuru, prova, müzakere veya prodüksiyon için mi?
- Belge kolay okunur mu olmalı, kolay karşılaştırılır mı, yoksa ikisi de mi?

En iyi dışa aktarım, bir sonraki konuşmaya en uygun olandır.

## Çevrilmiş oyun metnini dışa aktarmadan önce kontrol listesi

Çevrilmiş metni dışa aktarıp göndermeden önce şunları kontrol edin:

- Kaynak metin sürümü doğru mu?
- Tüm çevrilmiş satırlar tamam mı?
- Karakter adları tutarlı mı?
- Sahne yönergeleri diyalogdan açıkça ayrılmış mı?
- Perde ve sahne bölümleri korunmuş mu?
- Önemli duygusal sahneler insan tarafından gözden geçirilmiş mi?
- Kültürel göndermeler bilinçli biçimde ele alınmış mı?
- Şakalar, deyimler, şarkılar veya şiirsel satırlar gözden geçirilmiş mi?
- Dışa aktarım doğru sürüm durumu ile etiketlenmiş mi?
- Belge başvuru, iş birliği, prova veya performans için mi?
- Alıcı iki dilli sürüme mi, yalnızca çevrilmiş sürüme mi ihtiyaç duyuyor?
- Haklar, yazarlık ve çeviri kredisi doğru ele alınmış mı?
- Dosya özgün oyunu hiç görmemiş biri için okunabilir mi?

Güçlü bir çeviri dışa aktarımı okurun oyuna hızlıca girmesine yardımcı olmalıdır.

Önce format sorununu çözmesini gerektirmemelidir.

## Çevrilmiş metinden live surtitles’a

Metni yapılandırılmış tutmanın bir avantajı, çevirinin daha sonraki üretim ihtiyaçlarını destekleyebilmesidir.

Oyun bir festival tarafından kabul edilirse, okuma için seçilirse veya turneye geliştirilirse, aynı çevrilmiş materyal daha sonra şunlar için temel olabilir:

- live surtitles
- accessibility captions
- projected text
- mobile audience subtitles
- multilingual viewer options
- prova çevirisi referansları
- operator cue lists

Tam bir çevrilmiş oyun metni live surtitles ile aynı şey değildir. Surtitles genellikle daha kısa, zamanlanmış ve performans sırasında okunmaya uygun olmalıdır.

Ama yapılandırılmış bir çevrilmiş metin, dağınık bir çeviri belgesinden daha iyi bir başlangıç noktasıdır.

Ekip yeniden başlamak zorunda kalmaz.

## Uluslararası fırsatlara köprü olarak çeviri

Birçok tiyatrocu için çeviri, uluslararası fırsatlara atılan ilk adımdır.

Yurt dışındaki bir okur eseri anlayamıyorsa o oyun değerlendirilemez. Hikâye, yapımcının okuyamadığı bir dilin içinde kilitliyse ortak yapım konuşulamaz. Ekip okunabilir bir sürüm paylaşamıyorsa festival eseri programlamakta zorlanır.

Fakat tek başına çeviri yeterli değildir.

Çevrilmiş metin, oyuna saygı duyan bir biçimde ulaşmalıdır.

Okura karakterleri, ritmi, yapıyı ve eserin dünyasını göstermelidir. Metne girmeyi kolaylaştırmalı, çözmeyi zorlaştırmamalıdır.

Bu yüzden biçimlendirilmiş dışa aktarma önemlidir.

SurtitleLive tiyatro ekiplerinin ham çevirinin ötesine geçmesine yardımcı olur. Diller, bölgeler ve sanatsal konuşmalar arasında yolculuk edebilecek gözden geçirilmiş, yapılandırılmış ve biçimlendirilmiş bir çevrilmiş metin hazırlamalarını sağlar.

## FAQ

### Çevrilmiş bir oyun metni nasıl dışa aktarılır?

Çevrilmiş bir oyun metnini dışa aktarmak için önce özgün metni yapılandırın, her satır için çeviri oluşturun veya gözden geçirin, konuşan adlarını ve sahne yönergelerini kontrol edin, ardından okuma, başvuru veya iş birliği için biçimlendirilmiş bir çevrilmiş sürüm üretin. SurtitleLive bu script-first workflow’u destekler, böylece dışa aktarılan belge ham çeviri metni olmak yerine tiyatro yapısını korur.

### Uluslararası başvuru için çevrilmiş metin hangi formatta olmalı?

Okunabilir, açıkça etiketlenmiş ve tiyatro metni gibi formatlanmış olmalıdır. Karakter adları, diyalog, sahne yönergeleri, perde veya sahne bölümleri ve “English submission draft” ya da “working translation” gibi bir sürüm etiketi içermelidir.

### AI çeviri oyun metni formatını koruyabilir mi?

Genel AI çeviri araçları oyun metni formatını her zaman güvenilir şekilde koruyamayabilir. Metni çevirebilirler, ancak konuşan etiketlerini, sahne yönergelerini veya satır yapısını kaybedebilirler. Script-first workflow daha güvenlidir çünkü çeviri özgün tiyatro yapısına bağlı kalır.

### Biçimlendirilmiş çevrilmiş metin neden kopyalanmış çeviri metninden daha iyidir?

Festival, yapımcı, çevirmen, dramaturg ve iş birlikçilerin okuması daha kolaydır. Kimin konuştuğunu, sahnelerin nerede değiştiğini ve neyin sahne yönergesi olduğunu gösterir. Kopyalanmış çeviri metni çoğu zaman okurun veya tiyatro ekibinin belgeyi elle yeniden kurmasını gerektirir.

### SurtitleLive çevrilmiş bir metni dışa aktarabilir mi?

SurtitleLive ekiplerin kaynak metin satırlarını ve çevrilmiş satırları yapılandırılmış bir workflow içinde tutmasına, ardından inceleme, iş birliği ve prodüksiyon hazırlığı için biçimlendirilmiş materyaller dışa aktarmasına yardımcı olur. Bu, çeviri sonrası çevrilmiş metni elle yeniden kurma ihtiyacını azaltır.

### İki dilli metin mi, sadece çevrilmiş metin mi göndermeliyim?

Okura bağlıdır. Festival okuru temiz bir yalnızca çeviri metni tercih edebilir. Çevirmen, dramaturg veya ortak yapım partneri karşılaştırma için iki dilli sürümü tercih edebilir. Mümkünse alıcının bir sonraki kararına en uygun sürümü hazırlayın.

### Dışa aktarılan çevrilmiş metin daha sonra live surtitles olabilir mi?

Evet. Biçimlendirilmiş çevrilmiş metin live surtitles veya captions için temel olabilir; ancak performans sırasında okunabilir olması için timing, satır uzunluğu, cueing ve okunabilirlik açısından ek düzenleme gerektirir.

### Bir çevrilmiş metni dışa aktarmak çevirinin final olduğu anlamına mı gelir?

Hayır. Dışa aktarma kullanılabilir bir belge oluşturur, fakat çeviri amacına göre yine de gözden geçirilmelidir. Başvuru taslağı, prova taslağı, çevirmen tarafından gözden geçirilmiş sürüm ve final performans çevirisi farklı inceleme düzeyleri gerektirebilir.

## Çevrilmiş metninizi uluslararası okurlar için hazırlayın

Uluslararası başvuru, yabancı yapımcı incelemesi, festival programlama, ortak yapım görüşmesi veya çok dilli iş birliği için bir oyun hazırlıyorsanız çeviri dağınık bir metin dosyası olarak bitmemelidir.

Okunabilir bir tiyatro metnine dönüşmelidir.

SurtitleLive tiyatro ekiplerinin özgün metinleri yüklemesine, çevrilmiş satırları gözden geçirmesine ve uluslararası okurlarla paylaşması daha kolay biçimlendirilmiş çevrilmiş metinler dışa aktarmasına yardımcı olur.

[SurtitleLive ile çevrilmiş metninizi hazırlamaya başlayın](https://surtitlelive.com/auth/register)