---
title: 'Come preparare ed esportare un copione teatrale tradotto e formattato per una candidatura internazionale'
description: 'Scopri come preparare, revisionare ed esportare un copione teatrale tradotto e formattato per festival, produttori stranieri, coproduzioni e collaborazioni teatrali internazionali.'
pubDate: '2026-06-29'
heroImage: './export-translated-play-script-international-submission.png'
heroImageAlt: 'Un copione teatrale tradotto e formattato preparato per una candidatura teatrale internazionale'
tags: ['Traduzione teatrale', 'Traduzione di copioni', 'Esportazione copione', 'Teatro internazionale', 'SurtitleLive']
---

**Sintesi principale:**  
Un copione teatrale tradotto è davvero utile per una candidatura internazionale solo se è leggibile, strutturato e chiaramente formattato. La traduzione è il primo passo, ma i team teatrali devono anche conservare i nomi dei personaggi, i blocchi di dialogo, le didascalie, la struttura delle scene e le etichette di versione. SurtitleLive aiuta i team a passare da un copione originale in Word a traduzioni revisionate, per poi esportare un copione tradotto e formattato da condividere con festival, produttori stranieri, traduttori, dramaturg o partner di coproduzione.

Molti drammaturghi e compagnie teatrali pensano che la parte più difficile dell’inviare una pièce all’estero sia la traduzione.

Tradurre è difficile, ma risolve solo metà del problema.

Dopo che le parole sono state tradotte, qualcuno deve ancora ricostruire il copione. I nomi dei personaggi devono restare coerenti. Il dialogo deve restare leggibile. Le didascalie non devono essere scambiate per battute. Le interruzioni di scena devono rimanere. Il file finale deve sembrare un copione teatrale, non un output di traduzione automatica copiato e incollato.

È questo il problema di workflow che SurtitleLive è pensato per ridurre.

Invece di trattare la traduzione come una serie di testi scollegati, SurtitleLive mantiene la pièce come documento teatrale strutturato. Il team può revisionare le righe tradotte, affinare la lingua e poi esportare un copione tradotto e formattato per lettori internazionali.

Per drammaturghi, produttori, traduttori e compagnie che preparano candidature all’estero, festival, residenze, discussioni di tournée o coproduzioni, questo può trasformare la traduzione da un processo disordinato di copia e incolla in un workflow produttivo più pulito.

## La traduzione è solo il primo passo

Un copione teatrale tradotto non è finito solo perché le parole sono state convertite in un’altra lingua.

Un copione teatrale ha una struttura:

- nomi dei personaggi
- dialogo
- didascalie
- divisioni in atti e scene
- note di produzione
- canzoni o passaggi poetici
- frasi ricorrenti
- pause, silenzio e ritmo
- convenzioni di formattazione che aiutano il lettore a capire cosa viene detto e cosa no

Quando un copione viene copiato in uno strumento di traduzione generico, gran parte di questa struttura può andare perduta.

Il risultato può contenere testo tradotto, ma non essere ancora un copione tradotto utilizzabile.

Per esempio, un output di traduzione automatica può restituire un lungo blocco di testo. Può tradurre i nomi dei personaggi in modo incoerente. Può fondere le didascalie con il dialogo. Può eliminare a capo importanti. Può produrre qualcosa che aiuta a capire il significato, ma lascia comunque ore di formattazione manuale prima che il file possa essere inviato a un altro teatro.

Per una candidatura internazionale, la presentazione conta.

Un lettore di festival, un produttore straniero, un dramaturg o un partner di coproduzione non dovrebbe dover ricostruire il tuo copione prima di leggerlo. Ha bisogno di un documento pulito che mostri chiaramente la struttura della pièce.

Ecco perché la fase di esportazione è importante.

## Perché un copione tradotto e formattato è importante per il teatro internazionale

Quando mandi una pièce in un altro Paese o in un’altra regione, il copione tradotto diventa spesso il primo ponte tra il tuo lavoro e una nuova comunità artistica.

Il lettore potrebbe non conoscere la tua lingua, la tua scena teatrale, il tuo contesto culturale o lo stile della messinscena originale. Il copione tradotto deve aiutarlo a comprendere l’opera con sufficiente chiarezza da immaginarla in scena.

Un copione tradotto e formattato può aiutare in questi casi:

| Uso | Perché la formattazione conta |
| --- | --- |
| Candidatura a festival | I lettori possono seguire storia, personaggi e flusso delle scene senza confusione |
| Valutazione di produttori stranieri | I produttori possono capire se l’opera si adatta alla loro stagione, al loro spazio o al loro pubblico |
| Discussione di coproduzione | I partner possono discutere con precisione le stesse scene, battute e personaggi |
| Revisione della traduzione | Traduttori e dramaturg possono confrontare più facilmente testo originale e testo di arrivo |
| Domanda di residenza o finanziamento | Le commissioni possono leggere la pièce come documento teatrale coerente |
| Pianificazione delle prove | Registi e attori possono capire chi parla, quando e in quale contesto |
| Futuri surtitles o captions | Il testo tradotto strutturato può essere poi adattato in testo cue per il live |

Un copione tradotto e formattato non è solo più bello di un output grezzo. È più utile.

Dice al lettore:

- chi sta parlando
- cosa è una didascalia
- dove cambia la scena
- come scorre il dialogo
- se la traduzione è una bozza, una versione di candidatura o una versione revisionata
- come il testo tradotto si collega al copione originale

Nel teatro internazionale, questa chiarezza può fare la differenza tra un copione compreso e un copione abbandonato.

## Il problema del copia-incolla dopo la traduzione

Molti team gestiscono ancora la traduzione del copione con un processo manuale:

1. Copiare una sezione del copione originale.
2. Incollarla in uno strumento di traduzione.
3. Copiare il testo tradotto.
4. Incollarlo in un nuovo documento.
5. Ricostruire i nomi dei personaggi.
6. Ricostruire gli a capo.
7. Sistemare le didascalie.
8. Riparare la formattazione.
9. Ripetere finché l’intero copione è finito.

Funziona per poche pagine.

Diventa doloroso per una pièce intera.

Crea anche rischi. Il team può eliminare una riga per errore, duplicarne un’altra, attribuire male una battuta, perdere una didascalia o inviare una versione vecchia dopo che il copione è cambiato.

Il problema non è solo la qualità della traduzione. Il problema è il controllo del documento.

Se copione sorgente, righe tradotte, revisioni ed export finale vivono in file separati, il team deve gestire la coerenza manualmente. Diventa più difficile quando sono coinvolte più persone: autore, traduttrice, regista, dramaturg, produttrice o partner estero.

SurtitleLive nasce da un’idea diversa:

> Mantieni il copione strutturato fin dall’inizio, revisiona le traduzioni dentro quella struttura e poi esporta la versione tradotta dallo stesso workflow.

## Il workflow SurtitleLive: dal copione originale all’export tradotto e formattato

SurtitleLive supporta un workflow script-first per i team teatrali che hanno bisogno di copioni tradotti per uso internazionale.

Il processo può essere questo.

### 1. Carica il copione Word originale

Parti dal copione originale, idealmente come file Word `.docx` pulito.

Un copione in Word può conservare segnali importanti della formattazione teatrale: interruzioni di paragrafo, rientri, etichette dei personaggi, corsivi e altri formati che aiutano a distinguere il dialogo dalle didascalie.

SurtitleLive usa la struttura del copione caricato come base del workflow.

### 2. Revisiona la struttura del copione rilevata

Dopo il caricamento, il team revisiona la struttura del copione.

Questo può includere:

- nomi dei parlanti o dei personaggi
- righe di dialogo
- didascalie
- divisioni in scene o atti
- ruoli dei personaggi
- righe che richiedono correzione manuale

Questo passaggio è importante perché la traduzione è più facile da gestire quando il sistema sa che cosa rappresenta ogni riga.

Una battuta, una didascalia e un titolo non dovrebbero essere trattati allo stesso modo.

### 3. Genera o inserisci il testo tradotto

Una volta strutturato il copione sorgente, il team può creare il testo tradotto.

A seconda delle esigenze della produzione, questo può includere:

- bozze di traduzione assistite da AI
- input di traduttori umani
- bozze bilingui editate
- traduzioni esistenti incollate riga per riga
- versioni revisionate da traduttori
- bozze di lavoro specifiche per lingua

Il punto importante è che le traduzioni restino collegate alle righe del copione originale.

Questo rende la revisione più facile. Rende anche l’export più pulito.

### 4. Revisiona la traduzione riga per riga

Prima dell’export, il testo tradotto dovrebbe essere revisionato da una persona.

Nel teatro questo è particolarmente importante, perché la traduzione giusta non è sempre la più letterale.

I revisori possono controllare:

- voce dei personaggi
- ritmo
- sottotesto
- riferimenti culturali
- battute e modi di dire
- pressione emotiva
- lunghezza delle righe
- chiarezza scenica
- coerenza di nomi e termini

SurtitleLive aiuta a mantenere questa revisione dentro il workflow del copione, invece di costringere il team a confrontare documenti scollegati.

### 5. Scegli l’export del copione tradotto

Dopo che la traduzione è stata revisionata, il team può esportare un copione tradotto e formattato.

Questo è il passaggio chiave per la candidatura internazionale.

Invece di inviare una tabella di traduzione grezza o un documento copiato male, il team può creare una versione leggibile del copione che preserva la struttura teatrale.

Un export tradotto e formattato può essere usato per:

- candidature a festival
- copie di lettura per produttori stranieri
- discussioni di coproduzione
- revisione da parte di traduttori o dramaturg
- pianificazione delle prove
- comunicazione con partner
- prime conversazioni di tournée
- futura preparazione di surtitles o captions

L’export non è solo un file. È un documento di passaggio.

## Cosa dovrebbe includere un copione teatrale tradotto e formattato?

Un copione tradotto utile dovrebbe rendere chiara l’esperienza di lettura.

A seconda del contesto di candidatura o collaborazione, può includere:

- titolo tradotto
- titolo originale, se utile
- nome dell’autore
- traduttore o stato della bozza
- etichetta di versione, come “English submission draft”
- lista dei personaggi
- struttura di atti e scene
- nomi dei parlanti
- dialogo tradotto
- didascalie tradotte
- spaziatura coerente
- chiara separazione tra dialogo e didascalie
- note opzionali per termini culturalmente specifici
- informazioni di contatto o diritti, dove appropriato

Per una candidatura internazionale, le etichette di versione sono particolarmente importanti.

Il lettore dovrebbe sapere se sta leggendo:

- una prima bozza assistita da macchina
- una bozza di candidatura revisionata dall’autore
- un copione revisionato da un traduttore
- una traduzione letterale di riferimento
- una bozza di prova
- un adattamento per la messinscena
- una bozza di surtitles o captions

Sono documenti diversi. Un’etichettatura chiara protegge l’opera da fraintendimenti.

## Esempio: dal copione originale cantonese a una bozza di candidatura inglese

Immagina che un autore di Hong Kong voglia candidare una pièce in cantonese a un festival teatrale in Canada.

Il copione originale è scritto in cantonese. La storia è specifica della vita familiare di Hong Kong. L’umorismo dipende da ritmo, relazione e dettaglio culturale. Il lettore del festival, però, ha bisogno di una versione inglese prima di decidere se l’opera si adatta al programma.

Un workflow SurtitleLive pratico potrebbe essere:

1. L’autore carica il copione Word originale in cantonese.
2. SurtitleLive aiuta a identificare parlanti, dialoghi e didascalie.
3. Il team revisiona la struttura del copione.
4. Viene creata una bozza di traduzione inglese.
5. L’autore o il traduttore modifica l’inglese riga per riga.
6. Nomi dei personaggi, termini culturali e righe emotive vengono controllati con cura.
7. Il team esporta una bozza di candidatura inglese formattata.
8. Il file viene inviato al festival con una nota chiara sullo stato della traduzione.
9. Se il progetto va avanti, lo stesso testo strutturato può sostenere più tardi traduzione per le prove, surtitles, captions, proiezione o visione mobile per il pubblico.

Questo workflow non finge che il software possa sostituire il giudizio artistico.

Risolve un problema diverso: aiuta il team a passare dal copione originale a un documento tradotto e revisionato senza ricostruire manualmente il copione dopo la traduzione.

## Esempio: da una pièce spagnola a una bozza tedesca di coproduzione

Ora immagina una compagnia spagnola che prepara una conversazione di coproduzione con un teatro tedesco.

Il partner tedesco non ha ancora bisogno di una traduzione letteraria definitiva pronta per la pubblicazione. Ha bisogno di una bozza di lavoro leggibile per capire la storia, discutere la scala produttiva e decidere se il progetto merita sviluppo.

In questa situazione, l’export tradotto non deve essere la versione finale di scena.

Deve essere:

- leggibile
- strutturato
- chiaramente etichettato
- facile da discutere
- abbastanza vicino all’originale per una conversazione artistica
- modificabile per una successiva revisione della traduzione

La compagnia può preparare il copione sorgente in spagnolo, generare o inserire traduzioni tedesche, revisionare le scene chiave e poi esportare una bozza di lavoro tedesca formattata per il partner.

Più avanti, se il progetto entra in prova o produzione, il testo tradotto può essere affinato ulteriormente.

L’export aiuta la conversazione a iniziare prima.

## L’export non sostituisce la revisione umana

Un copione tradotto e formattato è potente, ma non garantisce che la traduzione sia artisticamente definitiva.

Per un lavoro teatrale serio, la revisione umana resta essenziale.

Prima di usare il copione esportato per una candidatura importante, una pubblicazione, una licenza o una produzione, il team dovrebbe considerare una revisione da parte di:

- l’autore
- un traduttore professionista
- un dramaturg
- un regista
- un madrelingua della lingua di arrivo
- un titolare dei diritti o editore, se necessario

SurtitleLive aiuta con struttura, workflow di traduzione, revisione ed export. Riduce il carico meccanico di ricostruire il copione tradotto. Non elimina la responsabilità per il giudizio artistico, legale o culturale.

Questa distinzione conta.

L’obiettivo non è rendere automatica la traduzione teatrale.

L’obiettivo è rendere il workflow meno fragile.

## Copione bilingue o solo tradotto?

Nella collaborazione internazionale, i team spesso chiedono se inviare un copione bilingue o solo il copione tradotto.

La risposta dipende dal lettore.

Un lettore di festival può preferire una versione solo tradotta e pulita, specialmente se non legge la lingua originale.

Un traduttore o dramaturg può preferire una versione bilingue per confrontare righe sorgente e target.

Un partner di coproduzione può volere entrambe: una bozza tradotta pulita per la discussione generale e una versione bilingue di lavoro per una revisione più profonda.

Quando prepari l’export, chiedi:

- Chi leggerà questo file?
- Capisce la lingua originale?
- Sta valutando la storia o controllando l’accuratezza della traduzione?
- È per candidatura, prove, negoziazione o produzione?
- Il documento deve essere facile da leggere, facile da confrontare, o entrambe le cose?

Il miglior export è quello che si adatta alla prossima conversazione.

## Checklist prima di esportare un copione tradotto

Prima di esportare e inviare il copione tradotto, controlla questa lista:

- La versione del copione sorgente è corretta?
- Tutte le righe tradotte sono complete?
- I nomi dei personaggi sono coerenti?
- Le didascalie sono chiaramente separate dal dialogo?
- Gli atti e le scene sono preservati?
- Un essere umano ha revisionato le scene emotive chiave?
- I riferimenti culturali sono stati trattati intenzionalmente?
- Battute, idiomi, canzoni o righe poetiche sono stati revisionati?
- L’export ha l’etichetta di versione corretta?
- Il documento è per candidatura, collaborazione, prove o performance?
- Il destinatario ha bisogno di una versione bilingue o solo tradotta?
- Diritti, autorialità e credito di traduzione sono gestiti correttamente?
- Il file è leggibile da qualcuno che non ha mai visto l’opera originale?

Un buon export tradotto dovrebbe aiutare il lettore a entrare rapidamente nella pièce.

Non dovrebbe costringerlo a risolvere prima la formattazione.

## Dal copione tradotto ai surtitles live

Uno dei vantaggi di mantenere il copione strutturato è che il testo tradotto può sostenere bisogni produttivi successivi.

Se la pièce viene accettata da un festival, scelta per una lettura o sviluppata per una tournée, lo stesso materiale tradotto può diventare la base per:

- surtitles live
- accessibility captions
- testo proiettato
- sottotitoli mobili per il pubblico
- opzioni viewer multilingue
- riferimenti di traduzione per le prove
- liste di cue per operatori

Un copione tradotto completo non è la stessa cosa dei surtitles live. I surtitles di solito devono essere più brevi, temporizzati e adattati alla lettura durante lo spettacolo.

Ma un copione tradotto strutturato è un punto di partenza migliore di un documento di traduzione sciolto.

Significa che il team non deve ricominciare da capo.

## La traduzione come ponte verso opportunità internazionali

Per molti artisti teatrali, la traduzione è il primo passo verso opportunità internazionali.

Una pièce non può essere presa in considerazione da un lettore straniero se quel lettore non la capisce. Un produttore non può discutere una coproduzione se la storia è chiusa in una lingua che non legge. Un festival non può programmare un lavoro se il team non può condividere una versione leggibile.

Ma la traduzione da sola non basta.

Il copione tradotto deve arrivare in una forma che rispetti l’opera.

Dovrebbe mostrare al lettore personaggi, ritmo, struttura e mondo del lavoro. Dovrebbe rendere più facile entrare nel testo, non più difficile decifrarlo.

Ecco perché l’export formattato conta.

SurtitleLive aiuta i team teatrali ad andare oltre la traduzione grezza. Li aiuta a preparare un copione tradotto, revisionato, strutturato e formattato che può viaggiare tra lingue, regioni e conversazioni artistiche.

## FAQ

### Come si esporta un copione teatrale tradotto?

Per esportare un copione teatrale tradotto, struttura prima il copione originale, revisiona o crea traduzioni per ogni riga, controlla nomi dei parlanti e didascalie, quindi genera una versione tradotta e formattata per lettura, candidatura o collaborazione. SurtitleLive supporta questo workflow script-first affinché il documento esportato conservi la struttura teatrale invece di diventare testo tradotto grezzo.

### Che formato dovrebbe avere un copione tradotto per una candidatura internazionale?

Un copione tradotto per una candidatura internazionale dovrebbe essere leggibile, chiaramente etichettato e formattato come un copione teatrale. Dovrebbe includere nomi dei personaggi, dialogo, didascalie, cambi di atto o scena e un’etichetta di versione come “English submission draft” o “working translation.”

### La traduzione AI può mantenere la formattazione di un copione teatrale?

Gli strumenti generici di traduzione AI potrebbero non preservare in modo affidabile la formattazione teatrale. Possono tradurre il testo, ma perdere etichette dei parlanti, didascalie o struttura delle righe. Un workflow script-first è più sicuro perché la traduzione resta collegata alla struttura teatrale originale.

### Perché un copione tradotto e formattato è migliore del testo tradotto copiato?

Un copione tradotto e formattato è più facile da leggere per festival, produttori, traduttori, dramaturg e collaboratori. Mostra chi parla, dove cambiano le scene e cosa è didascalia. Il testo tradotto copiato richiede spesso al lettore o al team teatrale di ricostruire manualmente il documento.

### SurtitleLive può esportare un copione tradotto?

SurtitleLive aiuta i team a mantenere righe sorgente e righe tradotte in un workflow strutturato, quindi a esportare materiali formattati per revisione, collaborazione e preparazione della produzione. Questo riduce la necessità di ricostruire manualmente un copione tradotto dopo la traduzione.

### Devo inviare un copione bilingue o solo tradotto?

Dipende dal lettore. Un lettore di festival può preferire un copione tradotto pulito. Un traduttore, dramaturg o partner di coproduzione può preferire una versione bilingue per confronto. Se possibile, prepara la versione più adatta alla prossima decisione che il destinatario deve prendere.

### Il copione tradotto esportato può diventare in seguito surtitles live?

Sì. Un copione tradotto e formattato può diventare la base per surtitles o captions live, ma di solito richiede ulteriore editing per timing, lunghezza delle righe, cueing e leggibilità durante la performance.

### Esportare un copione tradotto significa che la traduzione è definitiva?

No. L’export crea un documento utilizzabile, ma la traduzione deve comunque essere revisionata in base al suo scopo. Una bozza di candidatura, una bozza di prova, una versione revisionata da un traduttore e una traduzione finale per la scena possono richiedere livelli diversi di revisione.

## Prepara il tuo copione tradotto per lettori internazionali

Se stai preparando una pièce per candidatura internazionale, valutazione di produttori stranieri, programmazione di festival, discussione di coproduzione o collaborazione multilingue, la traduzione non dovrebbe finire come un file di testo disordinato.

Dovrebbe diventare un copione teatrale leggibile.

SurtitleLive aiuta i team teatrali a caricare copioni originali, revisionare righe tradotte ed esportare copioni tradotti e formattati più facili da condividere con lettori internazionali.

[Inizia a preparare il tuo copione tradotto con SurtitleLive](https://surtitlelive.com/auth/register)