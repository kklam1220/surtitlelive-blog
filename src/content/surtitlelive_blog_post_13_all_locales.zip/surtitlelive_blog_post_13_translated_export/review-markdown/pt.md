---
title: 'Como preparar e exportar um texto teatral traduzido e formatado para submissão internacional'
description: 'Saiba como preparar, rever e exportar um texto teatral traduzido e formatado para festivais, produtores estrangeiros, coproduções e colaboração teatral internacional.'
pubDate: '2026-06-29'
heroImage: './export-translated-play-script-international-submission.png'
heroImageAlt: 'Um texto teatral traduzido e formatado para submissão teatral internacional'
tags: ['Tradução teatral', 'Tradução de roteiro', 'Exportação de texto', 'Teatro internacional', 'SurtitleLive']
---

**Resumo principal:**  
Um texto teatral traduzido só é útil para uma submissão internacional se for legível, estruturado e claramente formatado. A tradução é o primeiro passo, mas as equipas de teatro também precisam de preservar nomes de personagens, blocos de diálogo, rubricas de cena, estrutura de cenas e etiquetas de versão. O SurtitleLive ajuda as equipas a passar de um guião original em Word para traduções revistas e, depois, a exportar um texto traduzido e formatado que pode ser partilhado com festivais, produtores estrangeiros, tradutores, dramaturgistas ou parceiros de coprodução.

Muitos dramaturgos e companhias de teatro pensam que a parte mais difícil de enviar uma peça para o estrangeiro é a tradução.

Traduzir é difícil, mas resolve apenas metade do problema.

Depois de as palavras estarem traduzidas, alguém ainda precisa de reconstruir o texto. Os nomes das personagens devem manter-se consistentes. O diálogo deve continuar legível. As rubricas de cena não devem ser confundidas com falas. As divisões de cena devem sobreviver. O ficheiro final deve parecer um texto teatral, não uma saída copiada de tradução automática.

É esse problema de workflow que o SurtitleLive foi desenhado para reduzir.

Em vez de tratar a tradução como uma pilha de textos desconectados, o SurtitleLive mantém a peça como um documento teatral estruturado. A equipa pode rever as linhas traduzidas, refinar a linguagem e depois exportar um texto traduzido e formatado para leitores internacionais.

Para dramaturgos, produtores, tradutores e companhias que preparam submissões no estrangeiro, festivais, residências, conversas de digressão ou coproduções, isto pode transformar a tradução de um processo confuso de copiar e colar num workflow de produção mais limpo.

## A tradução é apenas o primeiro passo

Um texto teatral traduzido não fica terminado só porque as palavras foram convertidas para outra língua.

Um texto de teatro tem estrutura:

- nomes de personagens
- diálogo
- rubricas de cena
- divisões de atos e cenas
- notas de produção
- canções ou passagens poéticas
- frases repetidas
- pausas, silêncio e ritmo
- convenções de formatação que ajudam o leitor a entender o que é falado e o que não é

Quando um texto é copiado para uma ferramenta genérica de tradução, muito dessa estrutura pode perder-se.

O resultado pode conter texto traduzido, mas não ser um texto teatral traduzido utilizável.

Por exemplo, uma saída de tradução automática pode devolver um longo bloco de texto. Pode traduzir nomes de personagens de modo inconsistente. Pode misturar rubricas com diálogo. Pode remover quebras de linha importantes. Pode ajudar a compreender o significado, mas ainda deixar horas de formatação manual antes de o ficheiro poder ser enviado a outro teatro.

Numa submissão internacional, a apresentação importa.

Um leitor de festival, produtor estrangeiro, dramaturgista ou parceiro de coprodução não deve ter de reconstruir o texto antes de o conseguir ler. Precisa de um documento limpo que mostre claramente a estrutura da peça.

É por isso que a etapa de exportação importa.

## Porque um texto traduzido e formatado importa no teatro internacional

Quando envia uma peça para outro país ou região, o texto traduzido torna-se muitas vezes a primeira ponte entre o seu trabalho e uma nova comunidade artística.

O leitor pode não conhecer a sua língua, a sua cena teatral, o seu contexto cultural ou o estilo original da encenação. O texto traduzido deve ajudá-lo a compreender a obra com clareza suficiente para a imaginar em palco.

Um texto traduzido e formatado pode ajudar em:

| Caso de uso | Porque a formatação importa |
| --- | --- |
| Submissão a festival | Os leitores conseguem seguir história, personagens e fluxo das cenas sem confusão |
| Revisão por produtor estrangeiro | Produtores podem avaliar se a obra se ajusta à sua temporada, espaço ou público |
| Discussão de coprodução | Parceiros podem discutir com precisão as mesmas cenas, falas e personagens |
| Revisão da tradução | Tradutores e dramaturgistas podem comparar mais facilmente texto de origem e texto de chegada |
| Residência ou candidatura a bolsa | Júris podem ler a peça como um documento teatral coerente |
| Planeamento de ensaios | Encenadores e atores entendem quem fala, quando e em que contexto |
| Futuros surtitles ou captions | Texto traduzido estruturado pode depois ser adaptado para cue text ao vivo |

Um texto traduzido e formatado não é apenas mais bonito do que uma tradução bruta. É mais útil.

Diz ao leitor:

- quem está a falar
- o que é rubrica de cena
- onde a cena muda
- como o diálogo flui
- se a tradução é rascunho, versão de submissão ou versão revista
- como o texto traduzido se relaciona com o original

No teatro internacional, essa clareza pode fazer a diferença entre uma peça ser compreendida ou abandonada.

## O problema do copiar e colar depois da tradução

Muitas equipas ainda tratam a tradução de textos teatrais manualmente:

1. Copiar uma secção do texto original.
2. Colá-la numa ferramenta de tradução.
3. Copiar a saída traduzida.
4. Colá-la num novo documento.
5. Reconstruir os nomes das personagens.
6. Reconstruir as quebras de linha.
7. Corrigir rubricas de cena.
8. Reparar a formatação.
9. Repetir até terminar o texto inteiro.

Isto funciona para poucas páginas.

Torna-se doloroso para uma peça completa.

Também cria riscos. A equipa pode eliminar uma linha sem querer, duplicar outra, atribuir uma fala à personagem errada, perder uma rubrica ou enviar uma versão antiga depois de o texto ter mudado.

O problema não é apenas a qualidade da tradução. É o controlo documental.

Se o texto de origem, as linhas traduzidas, as revisões e a exportação final vivem em ficheiros separados, a equipa tem de gerir consistência manualmente. Isto torna-se mais difícil quando estão envolvidas várias pessoas: dramaturgo, tradutora, encenador, dramaturgista, produtora ou parceiro estrangeiro.

O SurtitleLive parte de uma ideia diferente:

> Manter o texto estruturado desde o início, rever traduções dentro dessa estrutura e exportar a versão traduzida a partir do mesmo workflow.

## O workflow SurtitleLive: do texto original à exportação traduzida e formatada

O SurtitleLive suporta um workflow centrado no texto para equipas de teatro que precisam de textos traduzidos para uso internacional.

O processo pode ser assim.

### 1. Carregar o texto Word original

Comece pelo texto original, idealmente como um ficheiro Word `.docx` limpo.

Um texto em Word pode preservar sinais importantes de layout teatral: quebras de parágrafo, indentação, etiquetas de falante, itálicos e outras formatações que ajudam a distinguir diálogo de rubricas de cena.

O SurtitleLive usa a estrutura do texto carregado como base do workflow.

### 2. Rever a estrutura detetada

Depois do carregamento, a equipa revê a estrutura do texto.

Isto pode incluir:

- nomes de falantes ou personagens
- linhas de diálogo
- rubricas de cena
- divisões de cenas ou atos
- papéis das personagens
- linhas que precisam de correção manual

Este passo é importante porque a tradução é mais fácil de gerir quando o sistema sabe o que cada linha é.

Uma fala de personagem, uma rubrica e um título não devem ser tratados da mesma maneira.

### 3. Gerar ou inserir texto traduzido

Quando o texto de origem está estruturado, a equipa pode criar o texto traduzido.

Conforme as necessidades da produção, isto pode envolver:

- rascunhos de tradução assistidos por IA
- entrada de tradutores humanos
- rascunhos bilingues editados
- traduções existentes coladas linha a linha
- versões revistas por tradutores
- rascunhos de trabalho específicos por idioma

O ponto importante é que as traduções permanecem ligadas às linhas do texto original.

Isto facilita a revisão. Também torna a exportação mais limpa.

### 4. Rever a tradução linha a linha

Antes da exportação, o texto traduzido deve ser revisto por uma pessoa.

Isto é especialmente importante no teatro, onde a melhor tradução nem sempre é a mais literal.

Quem revê pode verificar:

- voz das personagens
- ritmo
- subtexto
- referências culturais
- piadas e idiomatismos
- pressão emocional
- comprimento das linhas
- clareza cénica
- consistência de nomes e termos

O SurtitleLive ajuda a manter esta revisão dentro do workflow do texto, em vez de obrigar a equipa a comparar documentos separados.

### 5. Escolher a exportação do texto traduzido

Depois de a tradução ser revista, a equipa pode exportar um texto traduzido e formatado.

Este é o passo-chave para submissão internacional.

Em vez de enviar uma tabela de tradução bruta ou um documento copiado e confuso, a equipa pode criar uma versão legível que preserva a estrutura teatral.

Uma exportação traduzida e formatada pode ser usada para:

- submissões a festivais
- cópias de leitura para produtores estrangeiros
- discussões de coprodução
- revisão por tradutor ou dramaturgista
- planeamento de ensaios
- comunicação com parceiros
- primeiras conversas de digressão
- preparação futura de surtitles ou captions

A exportação não é apenas um ficheiro. É um documento de passagem.

## O que deve incluir um texto teatral traduzido e formatado?

Um texto traduzido útil deve tornar a leitura clara.

Conforme o contexto de submissão ou colaboração, pode incluir:

- título traduzido
- título original, se útil
- nome do autor
- tradutor ou estado do rascunho
- etiqueta de versão, como “English submission draft”
- lista de personagens
- estrutura de atos e cenas
- nomes dos falantes
- diálogo traduzido
- rubricas traduzidas
- espaçamento consistente
- separação clara entre diálogo e indicações
- notas opcionais para termos culturalmente específicos
- informação de contacto ou direitos, quando adequado

Para submissão internacional, as etiquetas de versão são especialmente importantes.

O leitor deve saber se está a ler:

- um primeiro rascunho assistido por máquina
- uma versão de submissão revista pelo autor
- um texto revisto por tradutor
- uma tradução literal de referência
- um rascunho de ensaio
- uma adaptação para performance
- um rascunho de surtitles ou captions

São documentos diferentes. Etiquetagem clara protege a obra de mal-entendidos.

## Exemplo: de um original cantonês para um rascunho de submissão em inglês

Imagine um dramaturgo de Hong Kong que quer submeter uma peça em cantonês a um festival de teatro no Canadá.

O texto original está escrito em cantonês. A história é específica da vida familiar em Hong Kong. O humor depende de ritmo, relação e detalhe cultural. Porém, o leitor do festival precisa de uma versão em inglês antes de decidir se a obra cabe no programa.

Um workflow prático no SurtitleLive poderia ser:

1. O dramaturgo carrega o texto Word original em cantonês.
2. O SurtitleLive ajuda a identificar falantes, diálogo e rubricas.
3. A equipa revê a estrutura do texto.
4. É criado um rascunho de tradução em inglês.
5. O dramaturgo ou tradutor edita o inglês linha a linha.
6. Nomes de personagens, termos culturais e linhas emocionais são verificados com cuidado.
7. A equipa exporta um rascunho de submissão em inglês formatado.
8. O ficheiro é enviado ao festival com uma nota clara sobre o estado da tradução.
9. Se o projeto avançar, o mesmo texto estruturado pode depois apoiar tradução de ensaio, surtitles, captions, projeção ou visualização móvel para o público.

Este workflow não finge que o software substitui o julgamento artístico.

Resolve outro problema: ajuda a equipa a ir do texto original para um documento traduzido e revisto sem reconstruir manualmente o texto depois da tradução.

## Exemplo: de uma peça espanhola para um rascunho alemão de coprodução

Agora imagine uma companhia espanhola a preparar uma conversa de coprodução com um teatro alemão.

O parceiro alemão ainda não precisa de uma tradução literária final pronta para publicação. Precisa de um rascunho de trabalho legível para entender a história, discutir a escala de produção e decidir se o projeto merece desenvolvimento.

Nesta situação, a exportação traduzida não precisa de ser a versão final de performance.

Precisa de ser:

- legível
- estruturada
- claramente etiquetada
- fácil de discutir
- suficientemente próxima do original para conversa artística
- editável para revisão futura

A companhia pode preparar o texto de origem em espanhol, gerar ou inserir traduções em alemão, rever cenas-chave e depois exportar um rascunho de trabalho alemão formatado para o parceiro.

Mais tarde, se o projeto entrar em ensaio ou produção, o texto traduzido pode ser refinado.

A exportação ajuda a conversa a começar mais cedo.

## Exportar não substitui revisão humana

Um texto traduzido e formatado é poderoso, mas não garante que a tradução esteja artisticamente final.

Em trabalho teatral sério, a revisão humana continua importante.

Antes de usar o texto exportado para uma submissão importante, publicação, licenciamento ou produção, a equipa deve considerar revisão por:

- o dramaturgo
- um tradutor profissional
- um dramaturgista
- um encenador
- um falante nativo da língua de chegada
- um titular de direitos ou editora, se necessário

O SurtitleLive ajuda com estrutura, workflow de tradução, revisão e exportação. Reduz o esforço mecânico de reconstruir o texto traduzido. Não remove a responsabilidade pelo julgamento artístico, legal ou cultural.

Essa distinção importa.

O objetivo não é automatizar a tradução teatral.

O objetivo é tornar o workflow menos frágil.

## Texto bilingue ou apenas traduzido?

Na colaboração internacional, as equipas perguntam frequentemente se devem enviar um texto bilingue ou apenas a versão traduzida.

A resposta depende do leitor.

Um leitor de festival pode preferir uma versão traduzida limpa, especialmente se não lê a língua original.

Um tradutor ou dramaturgista pode preferir uma versão bilingue para comparar linhas de origem e de chegada.

Um parceiro de coprodução pode querer ambos: um rascunho traduzido limpo para discussão geral e uma versão bilingue de trabalho para revisão mais profunda.

Ao preparar a exportação, pergunte:

- Quem vai ler este ficheiro?
- Compreende a língua original?
- Está a avaliar a história ou a verificar precisão da tradução?
- Isto é para submissão, ensaio, negociação ou produção?
- O documento deve ser fácil de ler, fácil de comparar, ou ambos?

A melhor exportação é a que se ajusta à próxima conversa.

## Checklist antes de exportar um texto teatral traduzido

Antes de exportar e enviar o texto traduzido, verifique:

- A versão do texto de origem está correta?
- Todas as linhas traduzidas estão completas?
- Os nomes das personagens são consistentes?
- As rubricas estão claramente separadas do diálogo?
- As divisões de ato e cena foram preservadas?
- Alguém reviu as cenas emocionais principais?
- As referências culturais foram tratadas intencionalmente?
- Piadas, idiomatismos, canções ou linhas poéticas foram revistos?
- A exportação está etiquetada com o estado de versão correto?
- O documento é para submissão, colaboração, ensaio ou performance?
- O destinatário precisa de versão bilingue ou apenas traduzida?
- Direitos, autoria e crédito de tradução estão tratados corretamente?
- O ficheiro é legível por alguém que nunca viu a peça original?

Uma boa exportação traduzida deve ajudar o leitor a entrar rapidamente na peça.

Não deve obrigá-lo a resolver primeiro a formatação.

## Do texto traduzido aos live surtitles

Uma vantagem de manter o texto estruturado é que a tradução pode apoiar necessidades de produção posteriores.

Se a peça for aceite por um festival, selecionada para leitura ou desenvolvida para digressão, o mesmo material traduzido pode tornar-se base para:

- live surtitles
- accessibility captions
- texto projetado
- legendas móveis para público
- opções de viewer multilingue
- referências de tradução para ensaio
- listas de cue para operadores

Um texto traduzido completo não é o mesmo que live surtitles. Surtitles normalmente precisam de ser mais curtos, temporizados e adaptados para leitura durante a performance.

Mas um texto traduzido estruturado é um ponto de partida melhor do que um documento de tradução solto.

Significa que a equipa não precisa de recomeçar.

## A tradução como ponte para oportunidades internacionais

Para muitos criadores de teatro, a tradução é o primeiro passo para oportunidades internacionais.

Uma peça não pode ser considerada por um leitor estrangeiro se esse leitor não a compreender. Um produtor não pode discutir uma coprodução se a história estiver presa numa língua que não lê. Um festival não pode programar uma obra se a equipa não consegue partilhar uma versão legível.

Mas a tradução sozinha não basta.

O texto traduzido deve chegar numa forma que respeita a peça.

Deve mostrar ao leitor as personagens, o ritmo, a estrutura e o mundo da obra. Deve facilitar a entrada no texto, não tornar a leitura mais difícil de decifrar.

É por isso que a exportação formatada importa.

O SurtitleLive ajuda equipas de teatro a ir além da tradução bruta. Ajuda a preparar um texto traduzido, revisto, estruturado e formatado que pode viajar entre línguas, regiões e conversas artísticas.

## FAQ

### Como exporto um texto teatral traduzido?

Para exportar um texto teatral traduzido, primeiro estruture o texto original, reveja ou crie traduções para cada linha, verifique nomes de falantes e rubricas, e depois gere uma versão traduzida e formatada para leitura, submissão ou colaboração. O SurtitleLive suporta este workflow script-first para que o documento exportado preserve estrutura teatral em vez de se tornar texto traduzido bruto.

### Que formato deve ter um texto traduzido para submissão internacional?

Deve ser legível, claramente etiquetado e formatado como texto teatral. Deve incluir nomes de personagens, diálogo, rubricas, divisões de ato ou cena e uma etiqueta de versão como “English submission draft” ou “working translation.”

### A tradução por IA consegue preservar a formatação de um texto teatral?

Ferramentas genéricas de IA podem não preservar a formatação teatral de modo fiável. Podem traduzir texto, mas perder etiquetas de falante, rubricas ou estrutura de linhas. Um workflow script-first é mais seguro porque a tradução permanece ligada à estrutura teatral original.

### Porque um texto traduzido e formatado é melhor do que texto traduzido copiado?

É mais fácil de ler para festivais, produtores, tradutores, dramaturgistas e colaboradores. Mostra quem fala, onde as cenas mudam e o que é rubrica. Texto traduzido copiado muitas vezes obriga o leitor ou a equipa a reconstruir manualmente o documento.

### O SurtitleLive pode exportar um texto traduzido?

O SurtitleLive ajuda equipas a manter linhas de origem e linhas traduzidas num workflow estruturado e a exportar materiais formatados para revisão, colaboração e preparação de produção. Isto reduz a necessidade de reconstruir manualmente um texto traduzido depois da tradução.

### Devo enviar um texto bilingue ou apenas traduzido?

Depende do leitor. Um leitor de festival pode preferir uma versão apenas traduzida e limpa. Um tradutor, dramaturgista ou parceiro de coprodução pode preferir uma versão bilingue para comparação. Se possível, prepare a versão que melhor serve a próxima decisão do destinatário.

### O texto traduzido exportado pode tornar-se live surtitles mais tarde?

Sim. Um texto traduzido e formatado pode ser a base de live surtitles ou captions, mas normalmente precisa de edição adicional para timing, comprimento de linha, cueing e legibilidade durante a performance.

### Exportar um texto traduzido significa que a tradução é final?

Não. Exportar cria um documento utilizável, mas a tradução deve continuar a ser revista conforme o objetivo. Um rascunho de submissão, rascunho de ensaio, versão revista por tradutor e tradução final de performance podem exigir diferentes níveis de revisão.

## Prepare o seu texto traduzido para leitores internacionais

Se está a preparar uma peça para submissão internacional, revisão por produtor estrangeiro, programação de festival, conversa de coprodução ou colaboração multilingue, a tradução não deve acabar como um ficheiro de texto desordenado.

Deve tornar-se um texto teatral legível.

O SurtitleLive ajuda equipas de teatro a carregar textos originais, rever linhas traduzidas e exportar textos traduzidos e formatados que são mais fáceis de partilhar com leitores internacionais.

[Comece a preparar o seu texto traduzido com SurtitleLive](https://surtitlelive.com/auth/register)