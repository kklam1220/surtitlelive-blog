---
title: 'Comment préparer et exporter un texte théâtral traduit et mis en forme pour une candidature internationale'
description: 'Découvrez comment préparer, relire et exporter un texte théâtral traduit et mis en forme pour les festivals, producteurs étrangers, coproductions et collaborations théâtrales internationales.'
pubDate: '2026-06-29'
heroImage: './export-translated-play-script-international-submission.png'
heroImageAlt: 'Un texte théâtral traduit et mis en forme pour une candidature internationale'
tags: ['Traduction de théâtre', 'Traduction de texte théâtral', 'Export de script', 'Théâtre international', 'SurtitleLive']
---

**Résumé essentiel :**  
Un texte théâtral traduit n’est vraiment utile pour une candidature internationale que s’il est lisible, structuré et clairement mis en forme. La traduction est la première étape, mais les équipes théâtrales doivent aussi préserver les noms des personnages, les blocs de dialogue, les didascalies, la structure des scènes et les indications de version. SurtitleLive aide les équipes à passer d’un texte original en Word à des traductions relues, puis à exporter un texte théâtral traduit et mis en forme pouvant être partagé avec des festivals, des producteurs étrangers, des traducteurs, des dramaturges ou des partenaires de coproduction.

Beaucoup d’auteurs dramatiques et de compagnies pensent que la partie la plus difficile, lorsqu’une pièce doit voyager à l’étranger, est la traduction.

La traduction est difficile, mais elle ne résout que la moitié du problème.

Une fois les mots traduits, quelqu’un doit encore reconstruire le texte. Les noms des personnages doivent rester cohérents. Le dialogue doit rester lisible. Les didascalies ne doivent pas être prises pour des répliques. Les ruptures de scène doivent survivre. Le fichier final doit ressembler à un texte de théâtre, et non à une sortie de traduction automatique copiée-collée.

C’est précisément ce problème de workflow que SurtitleLive cherche à réduire.

Au lieu de traiter la traduction comme une pile de textes déconnectés, SurtitleLive conserve la pièce comme un document théâtral structuré. L’équipe peut relire les lignes traduites, affiner la langue, puis exporter un texte traduit et mis en forme pour des lecteurs internationaux.

Pour les auteurs, producteurs, traducteurs et compagnies qui préparent des candidatures à l’étranger, des festivals, des résidences, des discussions de tournée ou des coproductions, cela peut transformer la traduction d’un processus confus de copier-coller en un workflow de production plus propre.

## La traduction n’est que la première étape

Un texte théâtral traduit n’est pas terminé simplement parce que les mots ont été convertis dans une autre langue.

Un texte de théâtre possède une structure :

- noms de personnages
- dialogue
- didascalies
- actes et scènes
- notes de production
- chansons ou passages poétiques
- phrases répétées
- pauses, silence et rythme
- conventions de mise en forme qui aident le lecteur à comprendre ce qui est dit et ce qui ne l’est pas

Quand un texte est copié dans un outil de traduction générique, une grande partie de cette structure peut disparaître.

Le résultat peut contenir du texte traduit, sans pour autant être un texte théâtral traduit utilisable.

Par exemple, une sortie de traduction automatique peut produire un long bloc de texte. Elle peut traduire les noms des personnages de manière incohérente. Elle peut fusionner les didascalies avec les dialogues. Elle peut supprimer des retours à la ligne importants. Elle peut aider à comprendre le sens général, tout en laissant des heures de mise en forme manuelle avant que le fichier puisse être envoyé à un autre théâtre.

Pour une candidature internationale, la présentation compte.

Un lecteur de festival, un producteur étranger, un dramaturge ou un partenaire de coproduction ne devrait pas avoir à reconstruire votre texte avant de pouvoir le lire. Il a besoin d’un document propre qui montre clairement la structure de la pièce.

C’est pourquoi l’étape d’exportation est essentielle.

## Pourquoi un texte traduit et mis en forme compte pour le théâtre international

Lorsque vous envoyez une pièce dans un autre pays ou une autre région, le texte traduit devient souvent le premier pont entre votre œuvre et une nouvelle communauté artistique.

Le lecteur peut ne pas connaître votre langue, votre scène théâtrale, votre contexte culturel ou le style original de la représentation. Le texte traduit doit l’aider à comprendre l’œuvre assez clairement pour pouvoir l’imaginer sur scène.

Un texte traduit et mis en forme peut aider pour :

| Usage | Pourquoi la mise en forme compte |
| --- | --- |
| Candidature à un festival | Les lecteurs peuvent suivre l’histoire, les personnages et le déroulement des scènes sans confusion |
| Lecture par un producteur étranger | Les producteurs peuvent évaluer si l’œuvre correspond à leur saison, leur lieu ou leur public |
| Discussion de coproduction | Les partenaires peuvent parler plus précisément des mêmes scènes, répliques et personnages |
| Relecture de traduction | Traducteurs et dramaturges peuvent comparer plus facilement le texte source et le texte cible |
| Résidence ou demande de subvention | Les jurys peuvent lire la pièce comme un document théâtral cohérent |
| Préparation des répétitions | Metteurs en scène et acteurs peuvent comprendre qui parle, quand et dans quel contexte |
| Futurs surtitres ou captions | Un texte traduit structuré peut ensuite être adapté en texte de cues en direct |

Un texte traduit et mis en forme n’est pas seulement plus élégant qu’une traduction brute. Il est plus utile.

Il indique au lecteur :

- qui parle
- ce qui relève de la didascalie
- où la scène change
- comment le dialogue circule
- si la traduction est un brouillon, une version de candidature ou une version relue
- comment le texte traduit se rapporte au texte original

Dans le théâtre international, cette clarté peut faire la différence entre une pièce comprise et une pièce abandonnée.

## Le problème du copier-coller après la traduction

Beaucoup d’équipes gèrent encore la traduction d’un texte théâtral manuellement :

1. Copier une section du texte original.
2. La coller dans un outil de traduction.
3. Copier la sortie traduite.
4. La coller dans un nouveau document.
5. Reconstruire les noms des personnages.
6. Reconstruire les retours à la ligne.
7. Corriger les didascalies.
8. Réparer la mise en forme.
9. Répéter jusqu’à ce que toute la pièce soit terminée.

Cela fonctionne pour quelques pages.

Cela devient pénible pour une pièce entière.

Cela crée aussi des risques. L’équipe peut supprimer une ligne par accident, en dupliquer une autre, attribuer une réplique au mauvais personnage, perdre une didascalie ou envoyer une ancienne version après une modification du texte.

Le problème n’est pas seulement la qualité de la traduction. Le problème est le contrôle documentaire.

Si le texte source, les lignes traduites, les corrections et l’export final vivent dans des fichiers séparés, l’équipe doit gérer la cohérence à la main. Cela devient plus difficile lorsque plusieurs personnes sont impliquées : auteur, traductrice, metteur en scène, dramaturge, productrice ou partenaire à l’étranger.

SurtitleLive repose sur une autre idée :

> Garder le texte structuré dès le départ, relire les traductions à l’intérieur de cette structure, puis exporter la version traduite depuis le même workflow.

## Le workflow SurtitleLive : du texte original à l’export traduit et mis en forme

SurtitleLive prend en charge un workflow centré sur le texte pour les équipes théâtrales qui ont besoin de traductions destinées à un usage international.

Le processus peut ressembler à ceci.

### 1. Importer le texte original en Word

Commencez avec le texte original, idéalement sous forme de fichier Word `.docx` propre.

Un texte en Word peut préserver des signaux de mise en page importants pour le théâtre : paragraphes, retraits, noms de personnages, italiques et autres formats qui aident à distinguer les dialogues des didascalies.

SurtitleLive utilise la structure du fichier importé comme fondation du workflow.

### 2. Relire la structure détectée

Après l’import, l’équipe relit la structure du texte.

Cela peut inclure :

- noms de personnages ou de locuteurs
- lignes de dialogue
- didascalies
- divisions en scènes ou actes
- rôles des personnages
- lignes nécessitant une correction manuelle

Cette étape est importante parce que la traduction est plus facile à gérer lorsque le système sait ce qu’est chaque ligne.

Une réplique, une didascalie et un titre ne devraient pas être traités de la même manière.

### 3. Générer ou saisir le texte traduit

Une fois le texte source structuré, l’équipe peut créer le texte traduit.

Selon les besoins de la production, cela peut inclure :

- des brouillons de traduction assistée par IA
- une saisie par un traducteur humain
- des brouillons bilingues édités
- des traductions existantes collées ligne par ligne
- des versions relues par un traducteur
- des brouillons de travail propres à chaque langue

Le point important est que les traductions restent reliées aux lignes du texte original.

Cela facilite la relecture. Cela rend aussi l’export plus propre.

### 4. Relire la traduction ligne par ligne

Avant l’export, le texte traduit devrait être relu par une personne.

C’est particulièrement important au théâtre, où la bonne traduction n’est pas toujours la plus littérale.

Les relecteurs peuvent vérifier :

- la voix des personnages
- le rythme
- le sous-texte
- les références culturelles
- les blagues et expressions idiomatiques
- la pression émotionnelle
- la longueur des lignes
- la clarté scénique
- la cohérence des noms et des termes

SurtitleLive aide à maintenir cette relecture dans le workflow du texte, au lieu d’obliger l’équipe à comparer des documents séparés.

### 5. Choisir l’export du texte traduit

Une fois la traduction relue, l’équipe peut exporter un texte théâtral traduit et mis en forme.

C’est l’étape clé pour une candidature internationale.

Au lieu d’envoyer un tableau de traduction brut ou un document copié désordonné, l’équipe peut créer une version lisible du texte qui préserve la structure théâtrale.

Un export traduit et mis en forme peut servir pour :

- candidatures à des festivals
- copies de lecture pour producteurs étrangers
- discussions de coproduction
- relecture par traducteur ou dramaturge
- préparation des répétitions
- communication avec des partenaires
- premières discussions de tournée
- préparation future de surtitres ou captions

L’export n’est pas seulement un fichier. C’est un document de transmission.

## Que devrait contenir un texte théâtral traduit et mis en forme ?

Un texte traduit utile doit rendre l’expérience de lecture claire.

Selon le contexte de candidature ou de collaboration, il peut inclure :

- titre traduit
- titre original, si utile
- nom de l’auteur
- nom du traducteur ou statut du brouillon
- étiquette de version, par exemple « English submission draft »
- liste des personnages
- structure en actes et scènes
- noms des locuteurs
- dialogue traduit
- didascalies traduites
- interligne cohérent
- séparation claire entre dialogue et indications
- notes optionnelles pour les termes culturellement spécifiques
- informations de contact ou de droits, le cas échéant

Pour une candidature internationale, les étiquettes de version sont particulièrement importantes.

Le lecteur doit savoir s’il lit :

- un premier brouillon assisté par machine
- une version de candidature relue par l’auteur
- un texte relu par un traducteur
- une traduction littérale de référence
- un brouillon de répétition
- une adaptation de représentation
- un brouillon de surtitres ou captions

Ce sont des documents différents. Un étiquetage clair protège l’œuvre contre les malentendus.

## Exemple : d’un texte original cantonais à un brouillon de candidature en anglais

Imaginez qu’un auteur de Hong Kong souhaite soumettre une pièce en cantonais à un festival de théâtre au Canada.

Le texte original est écrit en cantonais. L’histoire est liée à la vie familiale hongkongaise. L’humour dépend du rythme, des relations et du détail culturel. Le lecteur du festival, cependant, a besoin d’une version anglaise avant de décider si l’œuvre convient au programme.

Un workflow SurtitleLive pratique pourrait ressembler à ceci :

1. L’auteur importe le texte original cantonais en Word.
2. SurtitleLive aide à identifier les locuteurs, dialogues et didascalies.
3. L’équipe relit la structure du texte.
4. Un brouillon de traduction anglaise est créé.
5. L’auteur ou le traducteur édite l’anglais ligne par ligne.
6. Les noms de personnages, termes culturels et lignes émotionnelles sont vérifiés avec soin.
7. L’équipe exporte un brouillon de candidature anglais mis en forme.
8. Le fichier est envoyé au festival avec une note claire sur l’état de la traduction.
9. Si le projet avance, le même texte structuré peut ensuite soutenir la traduction de répétition, les surtitres, les captions, la projection ou l’affichage mobile pour le public.

Ce workflow ne prétend pas que le logiciel peut remplacer le jugement artistique.

Il résout un autre problème : il aide l’équipe à passer du texte original à un document traduit et relu sans reconstruire manuellement le texte après traduction.

## Exemple : d’une pièce espagnole à un brouillon allemand de coproduction

Imaginez maintenant une compagnie espagnole préparant une discussion de coproduction avec un théâtre allemand.

Le partenaire allemand n’a pas encore besoin d’une traduction littéraire finale prête à publier. Il a besoin d’un brouillon de travail lisible pour comprendre l’histoire, discuter de l’échelle de production et décider si le projet mérite d’être développé.

Dans cette situation, l’export traduit n’a pas besoin d’être la version finale de représentation.

Il doit être :

- lisible
- structuré
- clairement étiqueté
- facile à discuter
- assez proche de l’original pour une conversation artistique
- modifiable pour une relecture de traduction ultérieure

La compagnie peut préparer le texte source espagnol, générer ou saisir des traductions allemandes, relire les scènes clés, puis exporter un brouillon de travail allemand mis en forme pour le partenaire.

Plus tard, si le projet entre en répétition ou en production, le texte traduit pourra être affiné davantage.

L’export permet à la conversation de commencer plus tôt.

## L’export ne remplace pas la relecture humaine

Un texte traduit et mis en forme est puissant, mais il ne garantit pas que la traduction est artistiquement définitive.

Pour un travail théâtral sérieux, la relecture humaine reste essentielle.

Avant d’utiliser le texte exporté pour une candidature importante, une publication, une licence ou une production, l’équipe devrait envisager une relecture par :

- l’auteur
- un traducteur professionnel
- un dramaturge
- un metteur en scène
- un locuteur natif de la langue cible
- un ayant droit ou éditeur, si nécessaire

SurtitleLive aide avec la structure, le workflow de traduction, la relecture et l’export. Il réduit la charge mécanique consistant à reconstruire le texte traduit. Il ne retire pas la responsabilité du jugement artistique, juridique ou culturel.

Cette distinction compte.

Le but n’est pas de rendre la traduction théâtrale automatique.

Le but est de rendre le workflow moins fragile.

## Texte bilingue ou texte traduit seulement ?

Dans la collaboration internationale, les équipes demandent souvent s’il faut envoyer un texte bilingue ou uniquement la version traduite.

La réponse dépend du lecteur.

Un lecteur de festival peut préférer une version traduite propre, surtout s’il ne lit pas la langue source.

Un traducteur ou dramaturge peut préférer une version bilingue afin de comparer les lignes source et cible.

Un partenaire de coproduction peut vouloir les deux : un brouillon de lecture traduit propre pour la discussion générale et une version de travail bilingue pour une relecture plus profonde.

Au moment de préparer votre export, demandez-vous :

- Qui lira ce fichier ?
- Cette personne comprend-elle la langue originale ?
- Évalue-t-elle l’histoire ou vérifie-t-elle l’exactitude de la traduction ?
- Est-ce pour une candidature, une répétition, une négociation ou une production ?
- Le document doit-il être facile à lire, facile à comparer, ou les deux ?

Le meilleur export est celui qui correspond à la prochaine conversation.

## Checklist avant d’exporter un texte théâtral traduit

Avant d’exporter et d’envoyer le texte traduit, vérifiez cette liste :

- La version du texte source est-elle correcte ?
- Toutes les lignes traduites sont-elles complètes ?
- Les noms des personnages sont-ils cohérents ?
- Les didascalies sont-elles clairement séparées du dialogue ?
- Les actes et scènes sont-ils préservés ?
- Une personne a-t-elle relu les scènes émotionnelles clés ?
- Les références culturelles sont-elles traitées intentionnellement ?
- Les blagues, expressions, chansons ou lignes poétiques ont-elles été relues ?
- L’export est-il étiqueté avec le bon statut de version ?
- Le document est-il destiné à une candidature, une collaboration, une répétition ou une représentation ?
- Le destinataire a-t-il besoin d’une version bilingue ou d’une version traduite seulement ?
- Les droits, l’auteur et le crédit de traduction sont-ils correctement indiqués ?
- Le fichier est-il lisible pour quelqu’un qui n’a jamais vu la pièce originale ?

Un bon export traduit devrait aider le lecteur à entrer rapidement dans la pièce.

Il ne devrait pas l’obliger à résoudre d’abord les problèmes de format.

## Du texte traduit aux surtitres en direct

L’un des avantages de conserver le texte structuré est que le texte traduit peut soutenir des besoins de production ultérieurs.

Si la pièce est acceptée par un festival, choisie pour une lecture ou développée pour une tournée, le même matériel traduit peut ensuite devenir la base de :

- surtitres en direct
- captions d’accessibilité
- texte projeté
- sous-titres mobiles pour le public
- options multilingues dans le viewer
- références de traduction pour les répétitions
- listes de cues pour l’opérateur

Un texte complet traduit n’est pas la même chose que des surtitres en direct. Les surtitres doivent généralement être plus courts, minutés et adaptés à la lecture pendant la représentation.

Mais un texte traduit structuré est un meilleur point de départ qu’un document de traduction libre.

Cela signifie que l’équipe n’a pas besoin de recommencer.

## La traduction comme pont vers les opportunités internationales

Pour de nombreux artistes de théâtre, la traduction est la première étape vers des opportunités internationales.

Une pièce ne peut pas être considérée par un lecteur étranger si celui-ci ne peut pas la comprendre. Un producteur ne peut pas discuter d’une coproduction si l’histoire reste enfermée dans une langue qu’il ne lit pas. Un festival ne peut pas programmer une œuvre si l’équipe ne peut pas partager une version lisible.

Mais la traduction seule ne suffit pas.

Le texte traduit doit arriver sous une forme qui respecte la pièce.

Il doit montrer au lecteur les personnages, le rythme, la structure et le monde de l’œuvre. Il doit rendre l’entrée dans le texte plus facile, pas plus difficile à décoder.

C’est pourquoi l’export mis en forme compte.

SurtitleLive aide les équipes théâtrales à aller au-delà de la traduction brute. Il les aide à préparer un texte traduit, relu, structuré et mis en forme, capable de voyager entre les langues, les régions et les conversations artistiques.

## FAQ

### Comment exporter un texte théâtral traduit ?

Pour exporter un texte théâtral traduit, commencez par structurer le texte original, relisez ou créez les traductions de chaque ligne, vérifiez les noms de personnages et les didascalies, puis générez une version traduite et mise en forme pour la lecture, la candidature ou la collaboration. SurtitleLive prend en charge ce workflow centré sur le texte afin que le document exporté conserve la structure théâtrale au lieu de devenir du texte traduit brut.

### Quel format utiliser pour un texte traduit destiné à une candidature internationale ?

Un texte traduit destiné à une candidature internationale devrait être lisible, clairement étiqueté et présenté comme un texte de théâtre. Il devrait inclure les noms des personnages, le dialogue, les didascalies, les actes ou scènes, ainsi qu’une étiquette de version comme « English submission draft » ou « working translation ».

### La traduction par IA peut-elle conserver la mise en forme d’un texte théâtral ?

Les outils de traduction IA génériques ne conservent pas toujours la mise en forme théâtrale de manière fiable. Ils peuvent traduire du texte, mais perdre les noms de locuteurs, les didascalies ou la structure des lignes. Un workflow centré sur le texte est plus sûr parce que la traduction reste reliée à la structure théâtrale d’origine.

### Pourquoi un texte traduit et mis en forme est-il meilleur qu’un texte de traduction copié ?

Un texte traduit et mis en forme est plus facile à lire pour les festivals, producteurs, traducteurs, dramaturges et collaborateurs. Il montre qui parle, où les scènes changent et ce qui relève de la didascalie. Un texte de traduction copié oblige souvent le lecteur ou l’équipe à reconstruire le document manuellement.

### SurtitleLive peut-il exporter un texte traduit ?

SurtitleLive aide les équipes à conserver les lignes source et les lignes traduites dans un workflow structuré, puis à exporter des documents mis en forme pour la relecture, la collaboration et la préparation de production. Cela réduit le besoin de reconstruire manuellement un texte traduit après la traduction.

### Faut-il envoyer un texte bilingue ou uniquement la version traduite ?

Cela dépend du lecteur. Un lecteur de festival peut préférer une version traduite propre. Un traducteur, un dramaturge ou un partenaire de coproduction peut préférer une version bilingue pour comparer. Si possible, préparez la version qui correspond le mieux à la prochaine décision que le destinataire doit prendre.

### Le texte traduit exporté peut-il ensuite devenir des surtitres en direct ?

Oui. Un texte traduit et mis en forme peut devenir la base de surtitres ou captions en direct, mais il aura généralement besoin d’une édition supplémentaire pour le timing, la longueur des lignes, le cueing et la lisibilité pendant la représentation.

### Exporter un texte traduit signifie-t-il que la traduction est finale ?

Non. L’export crée un document utilisable, mais la traduction doit encore être relue selon son objectif. Un brouillon de candidature, un brouillon de répétition, une version relue par traducteur et une traduction finale de représentation peuvent demander des niveaux de relecture différents.

## Préparez votre texte traduit pour les lecteurs internationaux

Si vous préparez une pièce pour une candidature internationale, une lecture par des producteurs étrangers, une programmation de festival, une discussion de coproduction ou une collaboration multilingue, la traduction ne devrait pas finir en fichier texte désordonné.

Elle devrait devenir un texte théâtral lisible.

SurtitleLive aide les équipes théâtrales à importer des textes originaux, relire les lignes traduites et exporter des textes traduits et mis en forme plus faciles à partager avec des lecteurs internationaux.

[Commencez à préparer votre texte traduit avec SurtitleLive](https://surtitlelive.com/auth/register)