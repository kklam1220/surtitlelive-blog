---
title: 'So bereiten Sie ein formatiertes übersetztes Theaterstück für internationale Einreichungen vor und exportieren es'
description: 'Erfahren Sie, wie Sie ein formatiertes übersetztes Theaterstück für Festivals, Produzenten im Ausland, Koproduktionen und internationale Theaterzusammenarbeit vorbereiten, prüfen und exportieren.'
pubDate: '2026-06-29'
heroImage: './export-translated-play-script-international-submission.png'
heroImageAlt: 'Ein formatiertes übersetztes Theaterstück, vorbereitet für eine internationale Theatereinreichung'
tags: ['Dramenübersetzung', 'Theaterübersetzung', 'Skriptexport', 'Internationales Theater', 'SurtitleLive']
---

**Kurzfassung:**  
Ein übersetztes Theaterstück ist für eine internationale Einreichung nur dann wirklich nützlich, wenn es lesbar, strukturiert und klar formatiert ist. Die Übersetzung ist der erste Schritt, aber Theaterteams müssen außerdem Rollennamen, Dialogblöcke, Regieanweisungen, Szenenstruktur und Versionshinweise erhalten. SurtitleLive hilft Teams, vom ursprünglichen Word-Skript zu geprüften Übersetzungen zu gelangen und anschließend ein formatiertes übersetztes Skript zu exportieren, das mit Festivals, Produzenten im Ausland, Übersetzerinnen und Übersetzern, Dramaturginnen und Dramaturgen oder Koproduktionspartnern geteilt werden kann.

Viele Autorinnen, Autoren und Theaterkompanien denken, dass die Übersetzung der schwierigste Teil ist, wenn ein Stück ins Ausland geschickt werden soll.

Übersetzung ist schwierig, aber sie ist nur die Hälfte des Problems.

Nachdem die Wörter übersetzt sind, muss jemand das Skript immer noch wieder aufbauen. Rollennamen müssen konsistent bleiben. Dialoge müssen lesbar sein. Regieanweisungen dürfen nicht mit gesprochenen Zeilen verwechselt werden. Szenenwechsel müssen erhalten bleiben. Die fertige Datei muss wie ein Theaterstück aussehen, nicht wie eine kopierte Maschinenübersetzung.

Genau dieses Workflow-Problem soll SurtitleLive reduzieren.

Statt Übersetzung als Ansammlung voneinander getrennter Textstücke zu behandeln, bewahrt SurtitleLive das Stück als strukturiertes Theaterdokument. Das Team kann die übersetzten Zeilen prüfen, die Sprache verfeinern und anschließend ein formatiertes übersetztes Skript für internationale Leserinnen und Leser exportieren.

Für Autorinnen, Produzenten, Übersetzerinnen und Theaterkompanien, die Einreichungen im Ausland, Festivals, Residenzen, Tournee-Gespräche oder Koproduktionen vorbereiten, kann dies Übersetzung von einem chaotischen Kopieren-und-Einfügen-Prozess in einen saubereren Produktionsworkflow verwandeln.

## Übersetzung ist nur der erste Schritt

Ein übersetztes Theaterstück ist nicht fertig, nur weil die Wörter in eine andere Sprache übertragen wurden.

Ein Theatertext hat eine eigene Struktur:

- Rollennamen
- Dialog
- Regieanweisungen
- Akt- und Szenenwechsel
- Produktionsnotizen
- Lieder oder poetische Passagen
- wiederkehrende Formulierungen
- Pausen, Stille und Rhythmus
- Formatkonventionen, die dem Lesenden helfen zu verstehen, was gesprochen wird und was nicht

Wenn ein Skript in ein allgemeines Übersetzungswerkzeug kopiert wird, kann viel von dieser Struktur verloren gehen.

Das Ergebnis enthält möglicherweise übersetzten Text, ist aber noch kein brauchbares übersetztes Theaterstück.

Eine maschinelle Übersetzung kann zum Beispiel einen langen Textblock liefern. Sie kann Rollennamen uneinheitlich übersetzen. Sie kann Regieanweisungen mit Dialog vermischen. Sie kann wichtige Zeilenumbrüche entfernen. Vielleicht hilft sie, die Bedeutung zu verstehen, aber sie lässt dem Team trotzdem Stunden manueller Formatierungsarbeit, bevor die Datei an ein anderes Theater geschickt werden kann.

Für internationale Einreichungen zählt die Präsentation.

Festival-Leserinnen, Produzenten im Ausland, Dramaturginnen oder Koproduktionspartner sollten Ihr Skript nicht erst rekonstruieren müssen, bevor sie es lesen können. Sie brauchen ein sauberes Dokument, das die Struktur des Stücks klar zeigt.

Deshalb ist die Exportphase so wichtig.

## Warum ein formatiertes übersetztes Skript für internationales Theater wichtig ist

Wenn Sie ein Stück in ein anderes Land oder eine andere Region schicken, wird das übersetzte Skript oft zur ersten Brücke zwischen Ihrer Arbeit und einer neuen künstlerischen Gemeinschaft.

Die Leserinnen und Leser kennen vielleicht Ihre Sprache, Ihre Theaterszene, Ihren kulturellen Kontext oder den ursprünglichen Aufführungsstil nicht. Das übersetzte Skript muss ihnen helfen, das Werk klar genug zu verstehen, um es sich auf der Bühne vorstellen zu können.

Ein formatiertes übersetztes Skript hilft bei:

| Anwendungsfall | Warum Formatierung wichtig ist |
| --- | --- |
| Festival-Einreichung | Leser können Geschichte, Figuren und Szenenfluss ohne Verwirrung verfolgen |
| Prüfung durch Produzenten im Ausland | Produzenten können einschätzen, ob das Werk zu ihrer Spielzeit, ihrem Raum oder ihrem Publikum passt |
| Koproduktionsgespräch | Partner können präziser über dieselben Szenen, Zeilen und Figuren sprechen |
| Übersetzungsprüfung | Übersetzer und Dramaturginnen können Ausgangs- und Zieltext leichter vergleichen |
| Residenz- oder Förderantrag | Jurys können das Stück als zusammenhängendes Theaterdokument lesen |
| Probenplanung | Regie und Schauspiel können verstehen, wer wann in welchem Kontext spricht |
| Spätere Übertitel oder Captions | Strukturierter übersetzter Text kann später zu Live-Cue-Text weiterverarbeitet werden |

Ein formatiertes übersetztes Skript ist nicht nur schöner als roher Übersetzungstext. Es ist nützlicher.

Es zeigt den Lesenden:

- wer spricht
- was Regieanweisung ist
- wo die Szene wechselt
- wie der Dialog fließt
- ob die Übersetzung ein Entwurf, eine Einreichungsfassung oder eine geprüfte Version ist
- wie sich der übersetzte Text auf das Originalskript bezieht

Im internationalen Theater kann diese Klarheit den Unterschied ausmachen, ob ein Stück verstanden oder beiseitegelegt wird.

## Das Copy-and-paste-Problem nach der Übersetzung

Viele Teams bearbeiten Skriptübersetzungen immer noch manuell:

1. Einen Abschnitt des Originalskripts kopieren.
2. In ein Übersetzungstool einfügen.
3. Die übersetzte Ausgabe kopieren.
4. In ein neues Dokument einfügen.
5. Rollennamen neu aufbauen.
6. Zeilenumbrüche neu aufbauen.
7. Regieanweisungen korrigieren.
8. Formatierung reparieren.
9. Wiederholen, bis das gesamte Skript fertig ist.

Für ein paar Seiten funktioniert das.

Bei einem abendfüllenden Stück wird es schmerzhaft.

Es erzeugt auch Risiken. Das Team kann versehentlich eine Zeile löschen, eine Zeile doppeln, eine Sprecherin falsch beschriften, eine Regieanweisung verlieren oder nach einer Skriptänderung eine alte Fassung verschicken.

Das Problem ist nicht nur die Übersetzungsqualität. Das Problem ist Dokumentkontrolle.

Wenn Originalskript, übersetzte Zeilen, Korrekturen und finaler Export in getrennten Dateien liegen, muss das Team Konsistenz manuell verwalten. Das wird schwieriger, wenn mehrere Personen beteiligt sind: Autor, Übersetzerin, Regie, Dramaturg, Produzentin oder Partner im Ausland.

SurtitleLive baut auf einer anderen Idee auf:

> Halten Sie das Skript von Anfang an strukturiert, prüfen Sie Übersetzungen innerhalb dieser Struktur und exportieren Sie die übersetzte Fassung aus demselben Workflow.

## Der SurtitleLive-Workflow: vom Originalskript zum formatierten Übersetzungsexport

SurtitleLive unterstützt einen skriptzentrierten Workflow für Theaterteams, die übersetzte Skripte für internationale Zwecke benötigen.

Der Prozess kann so aussehen.

### 1. Das originale Word-Skript hochladen

Beginnen Sie mit dem Originalskript, idealerweise als saubere Word-Datei im Format `.docx`.

Ein Word-Skript kann wichtige Layoutsignale des Theaters bewahren: Absatzumbrüche, Einzüge, Sprecherbezeichnungen, Kursivschrift und andere Formatierungen, die helfen, Dialog von Regieanweisungen zu unterscheiden.

SurtitleLive nutzt die Struktur des hochgeladenen Skripts als Grundlage des Workflows.

### 2. Die erkannte Skriptstruktur prüfen

Nach dem Upload prüft das Team die Skriptstruktur.

Dazu können gehören:

- Sprecher- bzw. Rollennamen
- Dialogzeilen
- Regieanweisungen
- Szenen- oder Aktunterteilungen
- Rolleninformationen
- Zeilen, die manuell korrigiert werden müssen

Dieser Schritt ist wichtig, weil Übersetzung leichter zu verwalten ist, wenn das System weiß, was jede Zeile ist.

Eine Figurenzeile, eine Regieanweisung und eine Überschrift sollten nicht gleich behandelt werden.

### 3. Übersetzten Text erzeugen oder eingeben

Sobald das Ausgangsskript strukturiert ist, kann das Team übersetzten Text erstellen.

Je nach Produktionsbedarf kann dies umfassen:

- KI-gestützte Übersetzungsentwürfe
- Eingaben professioneller Übersetzerinnen und Übersetzer
- bearbeitete zweisprachige Entwürfe
- vorhandene Übersetzungen, Zeile für Zeile eingefügt
- von Übersetzerinnen geprüfte Fassungen
- sprachspezifische Arbeitsentwürfe

Wichtig ist, dass die Übersetzungen mit den Zeilen des Originalskripts verbunden bleiben.

Das erleichtert die Prüfung. Es macht auch den Export sauberer.

### 4. Die Übersetzung Zeile für Zeile prüfen

Vor dem Export sollte der übersetzte Text von einem Menschen geprüft werden.

Das ist im Theater besonders wichtig, weil die richtige Übersetzung nicht immer die wörtlichste ist.

Prüfende können kontrollieren:

- Figurenstimme
- Rhythmus
- Subtext
- kulturelle Bezüge
- Witze und Redewendungen
- emotionalen Druck
- Zeilenlänge
- Klarheit der Regieanweisungen
- Konsistenz von Namen und Begriffen

SurtitleLive hilft, diese Prüfung im Skriptworkflow zu halten, statt das Team zum Vergleich getrennter Dokumente zu zwingen.

### 5. Den übersetzten Skriptexport wählen

Nachdem die Übersetzung geprüft wurde, kann das Team ein formatiertes übersetztes Skript exportieren.

Das ist der entscheidende Schritt für internationale Einreichungen.

Statt eine rohe Übersetzungstabelle oder ein unordentlich kopiertes Dokument zu versenden, kann das Team eine lesbare Skriptfassung erstellen, die die Theaterstruktur bewahrt.

Ein formatierter Übersetzungsexport kann verwendet werden für:

- Festival-Einreichungen
- Lesefassungen für Produzenten im Ausland
- Koproduktionsgespräche
- Übersetzungs- oder Dramaturgieprüfung
- Probenplanung
- Kommunikation mit Partnern
- frühe Tournee-Gespräche
- spätere Vorbereitung von Übertiteln oder Captions

Der Export ist nicht nur eine Datei. Er ist ein Übergabedokument.

## Was sollte ein formatiertes übersetztes Theaterstück enthalten?

Ein nützliches übersetztes Theaterstück sollte die Lektüre klar machen.

Je nach Einreichungs- oder Kooperationskontext kann es enthalten:

- übersetzten Titel
- Originaltitel, falls sinnvoll
- Namen der Autorin oder des Autors
- Übersetzerangabe oder Entwurfsstatus
- Versionshinweis, zum Beispiel „English submission draft“
- Figurenliste
- Akt- und Szenenstruktur
- Rollennamen
- übersetzten Dialog
- übersetzte Regieanweisungen
- konsistente Zeilenabstände
- klare Trennung zwischen Dialog und Anweisungen
- optionale Hinweise zu kulturspezifischen Begriffen
- Kontakt- oder Rechteinformationen, wo angemessen

Für internationale Einreichungen sind Versionshinweise besonders wichtig.

Der Leser sollte wissen, ob er liest:

- einen maschinengestützten ersten Entwurf
- eine vom Autor geprüfte Einreichungsfassung
- ein von einer Übersetzerin geprüftes Skript
- eine wörtliche Referenzübersetzung
- einen Probenentwurf
- eine Aufführungsbearbeitung
- einen Übertitel- oder Caption-Entwurf

Das sind unterschiedliche Dokumentarten. Klare Kennzeichnung schützt das Werk vor Missverständnissen.

## Beispiel: vom kantonesischen Originalskript zum englischen Einreichungsentwurf

Stellen Sie sich vor, ein Hongkonger Autor möchte ein kantonesisches Stück bei einem Theaterfestival in Kanada einreichen.

Das Originalskript ist auf Kantonesisch geschrieben. Die Geschichte ist eng mit dem Familienleben in Hongkong verbunden. Der Humor hängt von Rhythmus, Beziehung und kulturellem Detail ab. Der Festival-Leser braucht jedoch eine englische Fassung, bevor entschieden werden kann, ob das Werk ins Programm passt.

Ein praktischer SurtitleLive-Workflow könnte so aussehen:

1. Der Autor lädt das kantonesische Word-Originalskript hoch.
2. SurtitleLive hilft, Sprecher, Dialog und Regieanweisungen zu erkennen.
3. Das Team prüft die Skriptstruktur.
4. Ein englischer Übersetzungsentwurf wird erstellt.
5. Autor oder Übersetzerin bearbeiten das Englische Zeile für Zeile.
6. Rollennamen, kulturelle Begriffe und emotionale Zeilen werden sorgfältig geprüft.
7. Das Team exportiert einen formatierten englischen Einreichungsentwurf.
8. Die Datei wird mit einer klaren Notiz zum Übersetzungsstatus an das Festival geschickt.
9. Wenn das Projekt weitergeht, kann derselbe strukturierte Text später Probenübersetzung, Übertitel, Captions, Projektion oder mobile Zuschaueransicht unterstützen.

Dieser Workflow tut nicht so, als könne Software künstlerisches Urteil ersetzen.

Er löst ein anderes Problem: Er hilft dem Team, vom Originalskript zu einem geprüften übersetzten Dokument zu gelangen, ohne das Skript nach der Übersetzung manuell neu aufzubauen.

## Beispiel: spanisches Stück zum deutschen Koproduktionsentwurf

Stellen Sie sich nun eine spanische Theaterkompanie vor, die ein Koproduktionsgespräch mit einem deutschen Haus vorbereitet.

Der deutsche Partner braucht noch keine endgültige veröffentlichungsreife literarische Übersetzung. Er braucht einen lesbaren Arbeitsentwurf, um die Geschichte zu verstehen, Produktionsumfang zu besprechen und zu entscheiden, ob sich die Entwicklung des Projekts lohnt.

In dieser Situation muss der Übersetzungsexport nicht die endgültige Aufführungsfassung sein.

Er muss sein:

- lesbar
- strukturiert
- klar gekennzeichnet
- leicht zu besprechen
- nah genug am Original für künstlerische Gespräche
- später weiter bearbeitbar

Die Kompanie kann das spanische Ausgangsskript vorbereiten, deutsche Übersetzungen erzeugen oder eingeben, wichtige Szenen prüfen und dann einen formatierten deutschen Arbeitsentwurf für den Partner exportieren.

Wenn das Projekt später in Probe oder Produktion geht, kann der übersetzte Text weiter verfeinert werden.

Der Export hilft, das Gespräch früher zu beginnen.

## Export ersetzt keine menschliche Prüfung

Ein formatiertes übersetztes Skript ist wertvoll, aber es garantiert nicht, dass die Übersetzung künstlerisch endgültig ist.

Bei ernsthafter Theaterarbeit bleibt menschliche Prüfung wichtig.

Bevor das exportierte Skript für wichtige Einreichungen, Veröffentlichung, Lizenzierung oder Produktion verwendet wird, sollte das Team eine Prüfung erwägen durch:

- die Autorin oder den Autor
- eine professionelle Übersetzerin oder einen professionellen Übersetzer
- eine Dramaturgin oder einen Dramaturgen
- Regie
- eine muttersprachliche Person der Zielsprache
- Rechteinhaber oder Verlag, falls erforderlich

SurtitleLive hilft bei Struktur, Übersetzungsworkflow, Prüfung und Export. Es reduziert die mechanische Belastung, ein übersetztes Skript neu aufzubauen. Es nimmt nicht die Verantwortung für künstlerische, rechtliche oder kulturelle Entscheidungen ab.

Dieser Unterschied ist wichtig.

Das Ziel ist nicht, Theaterübersetzung automatisch zu machen.

Das Ziel ist, den Workflow weniger zerbrechlich zu machen.

## Zweisprachiges Skript oder nur Übersetzung?

In internationaler Zusammenarbeit fragen Teams oft, ob sie ein zweisprachiges Skript oder nur die übersetzte Fassung schicken sollten.

Die Antwort hängt vom Leser ab.

Ein Festival-Leser bevorzugt möglicherweise eine saubere Nur-Übersetzung, besonders wenn er die Ausgangssprache nicht liest.

Eine Übersetzerin oder ein Dramaturg bevorzugt vielleicht eine zweisprachige Fassung, um Ausgangs- und Zielzeilen vergleichen zu können.

Ein Koproduktionspartner möchte vielleicht beides: einen sauberen übersetzten Leseentwurf für allgemeine Gespräche und eine zweisprachige Arbeitsfassung für tiefere Prüfung.

Fragen Sie beim Vorbereiten des Exports:

- Wer wird diese Datei lesen?
- Versteht die Person die Originalsprache?
- Wird die Geschichte bewertet oder die Übersetzungsgenauigkeit geprüft?
- Ist dies für Einreichung, Probe, Verhandlung oder Produktion?
- Soll das Dokument leicht zu lesen, leicht zu vergleichen oder beides sein?

Der beste Export ist der, der zum nächsten Gespräch passt.

## Checkliste vor dem Export eines übersetzten Theaterstücks

Prüfen Sie vor dem Export und Versand des übersetzten Skripts diese Punkte:

- Ist die Version des Ausgangsskripts korrekt?
- Sind alle übersetzten Zeilen vollständig?
- Sind die Rollennamen konsistent?
- Sind Regieanweisungen klar vom Dialog getrennt?
- Sind Akt- und Szenenwechsel erhalten?
- Hat ein Mensch zentrale emotionale Szenen geprüft?
- Sind kulturelle Bezüge bewusst behandelt?
- Wurden Witze, Redewendungen, Lieder oder poetische Zeilen geprüft?
- Ist der Export mit dem richtigen Versionsstatus gekennzeichnet?
- Ist das Dokument für Einreichung, Zusammenarbeit, Probe oder Aufführung?
- Braucht der Empfänger eine zweisprachige oder eine reine Übersetzungsfassung?
- Sind Rechte, Urheberschaft und Übersetzungscredit korrekt geregelt?
- Ist die Datei für jemanden lesbar, der das Originalstück nie gesehen hat?

Ein starker Übersetzungsexport sollte dem Leser helfen, schnell in das Stück einzutreten.

Er sollte ihn nicht zuerst das Format reparieren lassen.

## Vom übersetzten Skript zu Live-Übertiteln

Ein Vorteil einer erhaltenen Skriptstruktur ist, dass der übersetzte Text spätere Produktionsbedürfnisse unterstützen kann.

Wenn das Stück von einem Festival angenommen, für eine Lesung ausgewählt oder für eine Tour entwickelt wird, kann dasselbe übersetzte Material später Grundlage sein für:

- Live-Übertitel
- barrierefreie Captions
- Projektionstext
- mobile Zuschaueruntertitel
- mehrsprachige Viewer-Optionen
- Übersetzungsreferenzen für Proben
- Cue-Listen für Operatoren

Ein vollständiges übersetztes Skript ist nicht dasselbe wie Live-Übertitel. Übertitel müssen in der Regel kürzer, getimt und für das Lesen während der Aufführung angepasst werden.

Aber ein strukturiertes übersetztes Skript ist ein besserer Ausgangspunkt als ein loses Übersetzungsdokument.

Das Team muss nicht wieder von vorne beginnen.

## Übersetzung als Brücke zu internationalen Chancen

Für viele Theatermacherinnen und Theatermacher ist Übersetzung der erste Schritt zu internationalen Möglichkeiten.

Ein Stück kann von einem Leser im Ausland nicht berücksichtigt werden, wenn er es nicht versteht. Ein Produzent kann keine Koproduktion besprechen, wenn die Geschichte in einer Sprache verschlossen bleibt, die er nicht liest. Ein Festival kann ein Werk kaum programmieren, wenn das Team keine lesbare Fassung teilen kann.

Aber Übersetzung allein genügt nicht.

Das übersetzte Skript muss in einer Form ankommen, die das Stück respektiert.

Es sollte dem Leser Figuren, Rhythmus, Struktur und Welt des Werks zeigen. Es sollte den Einstieg erleichtern, nicht das Entschlüsseln erschweren.

Deshalb zählt formatierter Export.

SurtitleLive hilft Theaterteams, über rohe Übersetzung hinauszugehen. Es hilft ihnen, ein geprüftes, strukturiertes und formatiertes übersetztes Skript vorzubereiten, das über Sprachen, Regionen und künstlerische Gespräche hinweg reisen kann.

## FAQ

### Wie exportiere ich ein übersetztes Theaterstück?

Um ein übersetztes Theaterstück zu exportieren, strukturieren Sie zuerst das Originalskript, prüfen oder erstellen Übersetzungen für jede Zeile, kontrollieren Sprecher- und Rollennamen sowie Regieanweisungen und erzeugen anschließend eine formatierte Übersetzungsfassung für Lektüre, Einreichung oder Zusammenarbeit. SurtitleLive unterstützt diesen skriptzentrierten Workflow, damit das exportierte Dokument Theaterstruktur bewahrt und nicht zu rohem Übersetzungstext wird.

### Welches Format sollte ein übersetztes Skript für internationale Einreichungen haben?

Ein übersetztes Skript für internationale Einreichungen sollte lesbar, klar gekennzeichnet und wie ein Theaterstück formatiert sein. Es sollte Rollennamen, Dialog, Regieanweisungen, Akt- oder Szenenwechsel und einen Versionshinweis wie „English submission draft“ oder „working translation“ enthalten.

### Kann KI-Übersetzung die Formatierung eines Theaterstücks erhalten?

Allgemeine KI-Übersetzungswerkzeuge erhalten Theaterformatierung nicht immer zuverlässig. Sie können Text übersetzen, aber Sprecherbezeichnungen, Regieanweisungen oder Zeilenstruktur verlieren. Ein skriptzentrierter Workflow ist sicherer, weil die Übersetzung mit der ursprünglichen Theaterstruktur verbunden bleibt.

### Warum ist ein formatiertes übersetztes Skript besser als kopierter Übersetzungstext?

Ein formatiertes übersetztes Skript ist für Festivals, Produzenten, Übersetzerinnen, Dramaturgen und Partner leichter zu lesen. Es zeigt, wer spricht, wo Szenen wechseln und was Regieanweisung ist. Kopierter Übersetzungstext verlangt oft, dass Leser oder Theaterteam das Dokument manuell neu aufbauen.

### Kann SurtitleLive ein übersetztes Skript exportieren?

SurtitleLive hilft Teams, Ausgangszeilen und übersetzte Zeilen in einem strukturierten Workflow zu halten und anschließend formatierte Materialien für Prüfung, Zusammenarbeit und Produktionsvorbereitung zu exportieren. Dadurch muss ein übersetztes Skript nach der Übersetzung nicht manuell neu aufgebaut werden.

### Soll ich ein zweisprachiges Skript oder nur die übersetzte Fassung schicken?

Das hängt vom Leser ab. Ein Festival-Leser bevorzugt möglicherweise eine saubere Nur-Übersetzung. Eine Übersetzerin, ein Dramaturg oder ein Koproduktionspartner bevorzugt vielleicht eine zweisprachige Fassung zum Vergleich. Bereiten Sie möglichst die Fassung vor, die zur nächsten Entscheidung des Empfängers passt.

### Kann das exportierte übersetzte Skript später zu Live-Übertiteln werden?

Ja. Ein formatiertes übersetztes Skript kann Grundlage für Live-Übertitel oder Captions werden, benötigt aber meist weitere Bearbeitung für Timing, Zeilenlänge, Cueing und Lesbarkeit während der Aufführung.

### Bedeutet der Export eines übersetzten Skripts, dass die Übersetzung endgültig ist?

Nein. Der Export erzeugt ein nutzbares Dokument, aber die Übersetzung sollte je nach Zweck weiter geprüft werden. Ein Einreichungsentwurf, Probenentwurf, eine übersetzergeprüfte Fassung und eine endgültige Aufführungsübersetzung können unterschiedliche Prüftiefen erfordern.

## Bereiten Sie Ihr übersetztes Skript für internationale Leser vor

Wenn Sie ein Stück für internationale Einreichung, Prüfung durch Produzenten im Ausland, Festivalprogrammierung, Koproduktionsgespräche oder mehrsprachige Zusammenarbeit vorbereiten, sollte die Übersetzung nicht als unordentliche Textdatei enden.

Sie sollte zu einem lesbaren Theaterstück werden.

SurtitleLive hilft Theaterteams, Originalskripte hochzuladen, übersetzte Zeilen zu prüfen und formatierte übersetzte Skripte zu exportieren, die leichter mit internationalen Leserinnen und Lesern geteilt werden können.

[Beginnen Sie mit SurtitleLive, Ihr übersetztes Skript vorzubereiten](https://surtitlelive.com/auth/register)