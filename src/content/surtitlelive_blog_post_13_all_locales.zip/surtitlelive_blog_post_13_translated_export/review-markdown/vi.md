---
title: 'Cách chuẩn bị và xuất một kịch bản dịch đã được định dạng cho hồ sơ quốc tế'
description: 'Tìm hiểu cách chuẩn bị, rà soát và xuất một kịch bản sân khấu đã dịch, có định dạng rõ ràng, cho liên hoan, nhà sản xuất nước ngoài, đồng sản xuất và hợp tác sân khấu quốc tế.'
pubDate: '2026-06-29'
heroImage: './export-translated-play-script-international-submission.png'
heroImageAlt: 'Một kịch bản sân khấu đã dịch và định dạng để nộp cho hoạt động sân khấu quốc tế'
tags: ['Dịch kịch bản', 'Dịch sân khấu', 'Xuất kịch bản', 'Sân khấu quốc tế', 'SurtitleLive']
---

**Tóm tắt chính:**  
Một kịch bản sân khấu đã dịch chỉ hữu ích cho hồ sơ quốc tế nếu nó dễ đọc, có cấu trúc và được định dạng rõ ràng. Dịch thuật là bước đầu tiên, nhưng các nhóm sân khấu cũng cần giữ lại tên nhân vật, các khối thoại, chỉ dẫn sân khấu, cấu trúc cảnh và nhãn phiên bản. SurtitleLive giúp các nhóm đi từ bản thảo Word gốc đến bản dịch đã được rà soát, rồi xuất một kịch bản dịch đã được định dạng để có thể chia sẻ với liên hoan, nhà sản xuất nước ngoài, dịch giả, dramaturg hoặc đối tác đồng sản xuất.

Nhiều nhà viết kịch và đoàn sân khấu nghĩ rằng phần khó nhất khi đưa một vở kịch ra nước ngoài là dịch thuật.

Dịch khó, nhưng đó chỉ là một nửa vấn đề.

Sau khi lời thoại đã được dịch, vẫn cần có người dựng lại kịch bản. Tên nhân vật phải nhất quán. Đối thoại phải dễ đọc. Chỉ dẫn sân khấu không được bị nhầm thành lời thoại. Các điểm chuyển cảnh phải được giữ lại. Tệp cuối cùng phải trông giống một kịch bản sân khấu, chứ không phải một kết quả dịch máy được sao chép.

Đó là vấn đề quy trình mà SurtitleLive được thiết kế để giảm bớt.

Thay vì xem bản dịch như một đống văn bản rời rạc, SurtitleLive giữ vở kịch như một tài liệu sân khấu có cấu trúc. Nhóm có thể rà soát từng dòng dịch, tinh chỉnh ngôn ngữ, rồi xuất một bản kịch dịch đã được định dạng cho độc giả quốc tế.

Đối với nhà viết kịch, nhà sản xuất, dịch giả và đoàn sân khấu đang chuẩn bị hồ sơ nước ngoài, liên hoan, chương trình lưu trú, trao đổi lưu diễn hoặc đồng sản xuất, điều này có thể biến việc dịch từ một quá trình sao chép-dán lộn xộn thành một quy trình sản xuất sạch hơn.

## Dịch thuật chỉ là bước đầu tiên

Một kịch bản dịch chưa hoàn tất chỉ vì các từ đã được chuyển sang ngôn ngữ khác.

Kịch bản sân khấu có cấu trúc:

- tên nhân vật
- đối thoại
- chỉ dẫn sân khấu
- phân chia hồi và cảnh
- ghi chú sản xuất
- bài hát hoặc đoạn văn giàu chất thơ
- cụm từ lặp lại
- khoảng dừng, im lặng và nhịp điệu
- quy ước định dạng giúp người đọc hiểu đâu là lời nói, đâu không phải lời nói

Khi một kịch bản được sao chép vào công cụ dịch chung, phần lớn cấu trúc này có thể bị mất.

Kết quả có thể chứa văn bản đã dịch, nhưng chưa chắc là một kịch bản dịch có thể sử dụng.

Ví dụ, đầu ra của dịch máy có thể là một khối văn bản dài. Nó có thể dịch tên nhân vật không nhất quán. Nó có thể trộn chỉ dẫn sân khấu vào đối thoại. Nó có thể xóa những xuống dòng quan trọng. Nó có thể giúp hiểu nghĩa, nhưng vẫn để lại hàng giờ định dạng thủ công trước khi tệp có thể được gửi cho một nhà hát khác.

Với hồ sơ quốc tế, cách trình bày rất quan trọng.

Người đọc của liên hoan, nhà sản xuất nước ngoài, dramaturg hoặc đối tác đồng sản xuất không nên phải tự tái cấu trúc kịch bản của bạn trước khi đọc. Họ cần một tài liệu sạch, cho thấy rõ cấu trúc của vở kịch.

Vì vậy, bước xuất tài liệu rất quan trọng.

## Vì sao một kịch bản dịch có định dạng lại quan trọng trong sân khấu quốc tế

Khi bạn gửi một vở kịch đến một quốc gia hoặc khu vực khác, bản dịch thường trở thành cây cầu đầu tiên giữa tác phẩm của bạn và một cộng đồng nghệ thuật mới.

Người đọc có thể không biết ngôn ngữ của bạn, bối cảnh sân khấu của bạn, ngữ cảnh văn hóa của bạn hoặc phong cách trình diễn ban đầu. Kịch bản dịch phải giúp họ hiểu tác phẩm đủ rõ để có thể hình dung nó trên sân khấu.

Một kịch bản dịch đã được định dạng có thể hỗ trợ:

| Trường hợp sử dụng | Vì sao định dạng quan trọng |
| --- | --- |
| Gửi hồ sơ liên hoan | Người đọc có thể theo dõi câu chuyện, nhân vật và dòng chảy cảnh mà không bị rối |
| Nhà sản xuất nước ngoài đọc duyệt | Nhà sản xuất có thể đánh giá tác phẩm có phù hợp với mùa diễn, không gian hoặc khán giả của họ không |
| Thảo luận đồng sản xuất | Các đối tác có thể bàn chính xác về cùng một cảnh, dòng thoại và nhân vật |
| Rà soát bản dịch | Dịch giả và dramaturg có thể so sánh văn bản nguồn và văn bản đích dễ hơn |
| Hồ sơ lưu trú hoặc tài trợ | Hội đồng có thể đọc vở kịch như một tài liệu sân khấu mạch lạc |
| Lập kế hoạch tập luyện | Đạo diễn và diễn viên hiểu ai nói, khi nào nói, trong ngữ cảnh nào |
| Surtitles hoặc captions về sau | Văn bản dịch có cấu trúc có thể được chuyển thành live cue text |

Một kịch bản dịch có định dạng không chỉ đẹp hơn văn bản dịch thô. Nó hữu dụng hơn.

Nó cho người đọc biết:

- ai đang nói
- đâu là chỉ dẫn sân khấu
- cảnh đổi ở đâu
- đối thoại chảy như thế nào
- bản dịch là bản nháp, bản gửi hồ sơ hay bản đã rà soát
- văn bản dịch liên hệ với bản gốc ra sao

Trong công việc sân khấu quốc tế, sự rõ ràng này có thể quyết định một kịch bản được hiểu hay bị bỏ qua.

## Vấn đề sao chép-dán sau khi dịch

Nhiều nhóm vẫn xử lý dịch kịch bản bằng cách thủ công:

1. Sao chép một phần kịch bản gốc.
2. Dán vào công cụ dịch.
3. Sao chép đầu ra đã dịch.
4. Dán vào tài liệu mới.
5. Dựng lại tên nhân vật.
6. Dựng lại xuống dòng.
7. Sửa chỉ dẫn sân khấu.
8. Sửa định dạng.
9. Lặp lại cho đến khi xong toàn bộ kịch bản.

Cách này có thể dùng cho vài trang.

Với một vở dài, nó trở nên rất mệt mỏi.

Nó cũng tạo ra rủi ro. Nhóm có thể vô tình bỏ sót một dòng, lặp lại một dòng, gán sai người nói, mất chỉ dẫn sân khấu hoặc gửi phiên bản cũ sau khi kịch bản đã thay đổi.

Vấn đề không chỉ là chất lượng dịch. Vấn đề là kiểm soát tài liệu.

Nếu kịch bản nguồn, dòng dịch, chỉnh sửa rà soát và bản xuất cuối cùng nằm trong các tệp riêng, nhóm phải tự quản lý tính nhất quán. Điều đó khó hơn khi có nhiều người tham gia: nhà viết kịch, dịch giả, đạo diễn, dramaturg, nhà sản xuất hoặc đối tác nước ngoài.

SurtitleLive dựa trên một ý tưởng khác:

> Giữ kịch bản có cấu trúc ngay từ đầu, rà soát bản dịch bên trong cấu trúc đó, rồi xuất phiên bản dịch từ cùng một quy trình.

## Quy trình SurtitleLive: từ kịch bản gốc đến bản dịch xuất có định dạng

SurtitleLive hỗ trợ quy trình script-first cho các nhóm sân khấu cần kịch bản dịch để dùng trong bối cảnh quốc tế.

Quy trình có thể như sau.

### 1. Tải lên kịch bản Word gốc

Bắt đầu với kịch bản gốc, lý tưởng nhất là một tệp Word `.docx` sạch.

Kịch bản Word có thể giữ những tín hiệu bố cục sân khấu quan trọng: ngắt đoạn, thụt lề, nhãn người nói, chữ nghiêng và các định dạng khác giúp phân biệt đối thoại với chỉ dẫn sân khấu.

SurtitleLive dùng cấu trúc của kịch bản đã tải lên làm nền tảng cho quy trình.

### 2. Rà soát cấu trúc kịch bản được nhận diện

Sau khi tải lên, nhóm rà soát cấu trúc kịch bản.

Điều này có thể bao gồm:

- tên người nói hoặc nhân vật
- dòng đối thoại
- chỉ dẫn sân khấu
- chia cảnh hoặc hồi
- vai trò nhân vật
- các dòng cần sửa thủ công

Bước này quan trọng vì việc dịch dễ quản lý hơn khi hệ thống biết mỗi dòng là gì.

Một dòng nhân vật, một chỉ dẫn sân khấu và một tiêu đề không nên được xử lý giống nhau.

### 3. Tạo hoặc nhập văn bản dịch

Khi kịch bản nguồn đã có cấu trúc, nhóm có thể tạo văn bản dịch.

Tùy nhu cầu sản xuất, việc này có thể bao gồm:

- bản nháp dịch có AI hỗ trợ
- bản dịch do người dịch nhập
- bản nháp song ngữ đã chỉnh sửa
- bản dịch có sẵn được dán theo từng dòng
- phiên bản đã được dịch giả rà soát
- bản nháp làm việc riêng cho từng ngôn ngữ

Điểm quan trọng là bản dịch vẫn được kết nối với từng dòng của kịch bản gốc.

Điều này giúp rà soát dễ hơn và khiến bản xuất sạch hơn.

### 4. Rà soát bản dịch theo từng dòng

Trước khi xuất, văn bản dịch nên được con người rà soát.

Điều này đặc biệt quan trọng trong sân khấu, vì bản dịch đúng không phải lúc nào cũng là bản dịch sát chữ nhất.

Người rà soát có thể kiểm tra:

- giọng nhân vật
- nhịp điệu
- ẩn ý
- tham chiếu văn hóa
- trò đùa và thành ngữ
- áp lực cảm xúc
- độ dài dòng
- độ rõ trên sân khấu
- tính nhất quán của tên và thuật ngữ

SurtitleLive giúp giữ việc rà soát này trong cùng quy trình kịch bản, thay vì buộc nhóm phải so sánh các tài liệu rời rạc.

### 5. Chọn xuất kịch bản dịch

Sau khi bản dịch được rà soát, nhóm có thể xuất một kịch bản dịch đã được định dạng.

Đây là bước then chốt cho hồ sơ quốc tế.

Thay vì gửi bảng dịch thô hoặc tài liệu sao chép lộn xộn, nhóm có thể tạo một phiên bản kịch bản dễ đọc, vẫn giữ cấu trúc sân khấu.

Bản xuất dịch có định dạng có thể dùng cho:

- hồ sơ gửi liên hoan
- bản đọc cho nhà sản xuất nước ngoài
- thảo luận đồng sản xuất
- rà soát của dịch giả hoặc dramaturg
- lập kế hoạch tập luyện
- trao đổi với đối tác
- thảo luận ban đầu về lưu diễn
- chuẩn bị surtitles hoặc captions về sau

Bản xuất không chỉ là một tệp. Nó là tài liệu bàn giao.

## Một kịch bản sân khấu dịch có định dạng nên có gì?

Một kịch bản dịch hữu ích nên làm trải nghiệm đọc trở nên rõ ràng.

Tùy bối cảnh gửi hồ sơ hoặc hợp tác, nó có thể bao gồm:

- tiêu đề đã dịch
- tiêu đề gốc, nếu hữu ích
- tên tác giả
- tên dịch giả hoặc trạng thái bản nháp
- nhãn phiên bản, như “English submission draft”
- danh sách nhân vật
- cấu trúc hồi và cảnh
- tên người nói
- đối thoại đã dịch
- chỉ dẫn sân khấu đã dịch
- khoảng cách dòng nhất quán
- phân biệt rõ giữa đối thoại và chỉ dẫn
- ghi chú tùy chọn cho thuật ngữ đặc thù văn hóa
- thông tin liên hệ hoặc quyền, nếu phù hợp

Với hồ sơ quốc tế, nhãn phiên bản đặc biệt quan trọng.

Người đọc cần biết họ đang đọc:

- bản nháp đầu tiên có máy hỗ trợ
- bản nháp gửi hồ sơ đã được tác giả rà soát
- kịch bản đã được dịch giả rà soát
- bản dịch sát nghĩa để tham chiếu
- bản nháp tập luyện
- bản chuyển thể biểu diễn
- bản nháp surtitles hoặc captions

Đây là những loại tài liệu khác nhau. Gắn nhãn rõ ràng giúp tránh hiểu nhầm về tác phẩm.

## Ví dụ: từ kịch bản gốc tiếng Quảng Đông sang bản nháp tiếng Anh để gửi hồ sơ

Hãy tưởng tượng một nhà viết kịch Hong Kong muốn gửi một vở tiếng Quảng Đông tới một liên hoan sân khấu ở Canada.

Kịch bản gốc viết bằng tiếng Quảng Đông. Câu chuyện gắn với đời sống gia đình Hong Kong. Hài hước dựa vào nhịp điệu, quan hệ và chi tiết văn hóa. Tuy nhiên, người đọc của liên hoan cần một bản tiếng Anh trước khi quyết định tác phẩm có phù hợp chương trình hay không.

Một quy trình SurtitleLive thực tế có thể như sau:

1. Nhà viết kịch tải lên kịch bản Word gốc tiếng Quảng Đông.
2. SurtitleLive giúp nhận diện người nói, đối thoại và chỉ dẫn sân khấu.
3. Nhóm rà soát cấu trúc kịch bản.
4. Một bản nháp dịch tiếng Anh được tạo.
5. Nhà viết kịch hoặc dịch giả chỉnh tiếng Anh theo từng dòng.
6. Tên nhân vật, thuật ngữ văn hóa và các dòng cảm xúc được kiểm tra kỹ.
7. Nhóm xuất bản nháp tiếng Anh đã định dạng để gửi hồ sơ.
8. Tệp được gửi cho liên hoan kèm ghi chú rõ về trạng thái bản dịch.
9. Nếu dự án đi tiếp, cùng văn bản có cấu trúc đó có thể hỗ trợ dịch cho tập luyện, surtitles, captions, projection hoặc mobile audience viewing.

Quy trình này không giả vờ rằng phần mềm có thể thay thế phán đoán nghệ thuật.

Nó giải quyết một vấn đề khác: giúp nhóm đi từ kịch bản gốc đến tài liệu dịch đã được rà soát mà không cần dựng lại kịch bản thủ công sau khi dịch.

## Ví dụ: từ vở Tây Ban Nha đến bản nháp tiếng Đức cho đồng sản xuất

Giờ hãy tưởng tượng một đoàn Tây Ban Nha đang chuẩn bị trao đổi đồng sản xuất với một địa điểm ở Đức.

Đối tác Đức chưa cần bản dịch văn học cuối cùng để xuất bản. Họ cần một bản nháp làm việc dễ đọc để hiểu câu chuyện, bàn quy mô sản xuất và quyết định dự án có đáng phát triển hay không.

Trong tình huống này, bản xuất dịch không cần là phiên bản biểu diễn cuối cùng.

Nó cần:

- dễ đọc
- có cấu trúc
- được gắn nhãn rõ
- dễ thảo luận
- đủ gần bản gốc cho trao đổi nghệ thuật
- có thể chỉnh sửa cho đợt rà soát dịch tiếp theo

Đoàn có thể chuẩn bị kịch bản nguồn tiếng Tây Ban Nha, tạo hoặc nhập bản dịch tiếng Đức, rà soát các cảnh chính, rồi xuất bản nháp làm việc tiếng Đức đã định dạng cho đối tác.

Sau này, nếu dự án đi vào tập luyện hoặc sản xuất, văn bản dịch có thể tiếp tục được tinh chỉnh.

Bản xuất giúp cuộc trao đổi bắt đầu sớm hơn.

## Xuất tài liệu không thay thế rà soát của con người

Một kịch bản dịch đã định dạng rất hữu ích, nhưng nó không bảo đảm bản dịch đã hoàn tất về mặt nghệ thuật.

Với công việc sân khấu nghiêm túc, rà soát của con người vẫn quan trọng.

Trước khi dùng bản xuất cho hồ sơ lớn, xuất bản, cấp phép hoặc sản xuất, nhóm nên cân nhắc việc rà soát bởi:

- nhà viết kịch
- dịch giả chuyên nghiệp
- dramaturg
- đạo diễn
- người bản ngữ của ngôn ngữ đích
- chủ sở hữu quyền hoặc nhà xuất bản, nếu cần

SurtitleLive hỗ trợ cấu trúc, quy trình dịch, rà soát và xuất tài liệu. Nó giảm gánh nặng cơ học của việc dựng lại kịch bản dịch. Nó không loại bỏ trách nhiệm về phán đoán nghệ thuật, pháp lý hoặc văn hóa.

Sự phân biệt này rất quan trọng.

Mục tiêu không phải là làm cho dịch sân khấu trở thành tự động hoàn toàn.

Mục tiêu là làm quy trình ít mong manh hơn.

## Kịch bản song ngữ hay chỉ bản dịch?

Trong hợp tác quốc tế, các nhóm thường hỏi nên gửi kịch bản song ngữ hay chỉ gửi bản dịch.

Câu trả lời tùy người đọc.

Người đọc của liên hoan có thể thích bản dịch sạch, đặc biệt nếu họ không đọc được ngôn ngữ nguồn.

Dịch giả hoặc dramaturg có thể thích bản song ngữ để so sánh dòng nguồn và dòng đích.

Đối tác đồng sản xuất có thể muốn cả hai: bản dịch sạch để thảo luận chung và bản song ngữ làm việc để rà soát sâu hơn.

Khi chuẩn bị xuất, hãy hỏi:

- Ai sẽ đọc tệp này?
- Họ có hiểu ngôn ngữ gốc không?
- Họ đang đánh giá câu chuyện hay kiểm tra độ chính xác của bản dịch?
- Đây là tài liệu cho hồ sơ, tập luyện, đàm phán hay sản xuất?
- Tài liệu cần dễ đọc, dễ so sánh hay cả hai?

Bản xuất tốt nhất là bản phù hợp với cuộc trao đổi tiếp theo.

## Checklist trước khi xuất một kịch bản dịch

Trước khi xuất và gửi kịch bản dịch, hãy kiểm tra:

- Phiên bản kịch bản nguồn đã đúng chưa?
- Tất cả các dòng dịch đã hoàn chỉnh chưa?
- Tên nhân vật có nhất quán không?
- Chỉ dẫn sân khấu có được tách rõ khỏi đối thoại không?
- Các phân chia hồi và cảnh có được giữ lại không?
- Các cảnh cảm xúc quan trọng đã được con người rà soát chưa?
- Các tham chiếu văn hóa đã được xử lý có chủ ý chưa?
- Trò đùa, thành ngữ, bài hát hoặc dòng thơ đã được rà soát chưa?
- Bản xuất có nhãn đúng trạng thái phiên bản không?
- Tài liệu này dùng cho hồ sơ, hợp tác, tập luyện hay biểu diễn?
- Người nhận cần bản song ngữ hay chỉ bản dịch?
- Quyền, tác giả và credit dịch thuật đã được xử lý đúng chưa?
- Tệp có dễ đọc với người chưa từng xem bản gốc không?

Một bản xuất dịch tốt nên giúp người đọc bước vào vở kịch nhanh chóng.

Nó không nên bắt họ giải quyết vấn đề định dạng trước.

## Từ kịch bản dịch đến live surtitles

Một lợi ích của việc giữ kịch bản có cấu trúc là văn bản dịch có thể hỗ trợ nhu cầu sản xuất về sau.

Nếu vở kịch được liên hoan chấp nhận, được chọn đọc diễn, hoặc phát triển thành tour, cùng chất liệu dịch đó có thể trở thành nền tảng cho:

- live surtitles
- accessibility captions
- projected text
- mobile audience subtitles
- multilingual viewer options
- tài liệu tham chiếu dịch cho tập luyện
- operator cue lists

Một kịch bản dịch đầy đủ không giống live surtitles. Surtitles thường cần ngắn hơn, được canh thời gian và điều chỉnh để đọc trong khi biểu diễn.

Nhưng một kịch bản dịch có cấu trúc là điểm bắt đầu tốt hơn nhiều so với một tài liệu dịch rời rạc.

Nghĩa là nhóm không phải bắt đầu lại từ đầu.

## Dịch thuật như cây cầu đến cơ hội quốc tế

Với nhiều người làm sân khấu, dịch thuật là bước đầu tiên đến cơ hội quốc tế.

Một vở kịch không thể được người đọc nước ngoài cân nhắc nếu họ không hiểu nó. Một nhà sản xuất không thể bàn đồng sản xuất nếu câu chuyện bị khóa trong ngôn ngữ họ không đọc. Một liên hoan khó có thể lập chương trình cho tác phẩm nếu nhóm không thể chia sẻ một phiên bản dễ đọc.

Nhưng chỉ dịch thôi chưa đủ.

Kịch bản dịch phải đến trong một hình thức tôn trọng tác phẩm.

Nó nên cho người đọc thấy nhân vật, nhịp điệu, cấu trúc và thế giới của tác phẩm. Nó nên giúp họ bước vào văn bản dễ hơn, không làm việc giải mã trở nên khó hơn.

Đó là lý do bản xuất có định dạng quan trọng.

SurtitleLive giúp các nhóm sân khấu vượt qua bản dịch thô. Nó giúp họ chuẩn bị một kịch bản dịch đã được rà soát, có cấu trúc và định dạng để có thể đi qua các ngôn ngữ, khu vực và cuộc trò chuyện nghệ thuật.

## FAQ

### Làm thế nào để xuất một kịch bản sân khấu đã dịch?

Để xuất một kịch bản sân khấu đã dịch, trước tiên hãy cấu trúc kịch bản gốc, rà soát hoặc tạo bản dịch cho từng dòng, kiểm tra tên người nói và chỉ dẫn sân khấu, rồi tạo phiên bản dịch đã định dạng cho việc đọc, gửi hồ sơ hoặc hợp tác. SurtitleLive hỗ trợ quy trình script-first này để tài liệu xuất ra giữ được cấu trúc sân khấu thay vì trở thành văn bản dịch thô.

### Kịch bản dịch để gửi hồ sơ quốc tế nên có định dạng nào?

Nó nên dễ đọc, được gắn nhãn rõ và trình bày như một kịch bản sân khấu. Nó nên có tên nhân vật, đối thoại, chỉ dẫn sân khấu, phân chia hồi hoặc cảnh và nhãn phiên bản như “English submission draft” hoặc “working translation.”

### AI có thể giữ định dạng kịch bản sân khấu khi dịch không?

Các công cụ AI dịch chung có thể không giữ định dạng kịch bản sân khấu một cách đáng tin cậy. Chúng có thể dịch văn bản, nhưng có thể làm mất nhãn người nói, chỉ dẫn sân khấu hoặc cấu trúc dòng. Quy trình script-first an toàn hơn vì bản dịch vẫn gắn với cấu trúc sân khấu gốc.

### Vì sao kịch bản dịch có định dạng tốt hơn văn bản dịch được sao chép?

Kịch bản dịch có định dạng dễ đọc hơn cho liên hoan, nhà sản xuất, dịch giả, dramaturg và cộng tác viên. Nó cho thấy ai đang nói, cảnh đổi ở đâu và đâu là chỉ dẫn sân khấu. Văn bản dịch sao chép thường khiến người đọc hoặc nhóm sân khấu phải dựng lại tài liệu bằng tay.

### SurtitleLive có thể xuất kịch bản dịch không?

SurtitleLive giúp các nhóm giữ dòng nguồn và dòng dịch trong một quy trình có cấu trúc, rồi xuất tài liệu đã định dạng để rà soát, hợp tác và chuẩn bị sản xuất. Điều này giảm nhu cầu dựng lại kịch bản dịch thủ công sau khi dịch.

### Tôi nên gửi kịch bản song ngữ hay chỉ gửi bản dịch?

Tùy người đọc. Người đọc của liên hoan có thể thích bản dịch sạch. Dịch giả, dramaturg hoặc đối tác đồng sản xuất có thể thích bản song ngữ để so sánh. Nếu có thể, hãy chuẩn bị phiên bản phù hợp nhất với quyết định tiếp theo mà người nhận cần đưa ra.

### Kịch bản dịch đã xuất có thể trở thành live surtitles không?

Có. Một kịch bản dịch đã định dạng có thể trở thành nền tảng cho live surtitles hoặc captions, nhưng thường cần chỉnh thêm về timing, độ dài dòng, cueing và khả năng đọc trong lúc biểu diễn.

### Xuất kịch bản dịch có nghĩa là bản dịch đã cuối cùng chưa?

Không. Việc xuất tạo ra một tài liệu có thể sử dụng, nhưng bản dịch vẫn nên được rà soát theo mục đích. Bản nháp gửi hồ sơ, bản nháp tập luyện, phiên bản đã được dịch giả rà soát và bản dịch biểu diễn cuối cùng có thể cần các mức rà soát khác nhau.

## Chuẩn bị kịch bản dịch của bạn cho độc giả quốc tế

Nếu bạn đang chuẩn bị một vở kịch để gửi hồ sơ quốc tế, cho nhà sản xuất nước ngoài đọc, lập chương trình liên hoan, thảo luận đồng sản xuất hoặc hợp tác đa ngôn ngữ, bản dịch không nên kết thúc như một tệp văn bản lộn xộn.

Nó nên trở thành một kịch bản sân khấu có thể đọc được.

SurtitleLive giúp các nhóm sân khấu tải lên kịch bản gốc, rà soát các dòng dịch và xuất kịch bản dịch đã định dạng để dễ chia sẻ hơn với độc giả quốc tế.

[Bắt đầu chuẩn bị kịch bản dịch của bạn với SurtitleLive](https://surtitlelive.com/auth/register)