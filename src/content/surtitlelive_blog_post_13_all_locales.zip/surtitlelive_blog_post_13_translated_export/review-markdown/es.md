---
title: 'Cómo preparar y exportar un guion teatral traducido y maquetado para una presentación internacional'
description: 'Aprende a preparar, revisar y exportar un guion teatral traducido y con formato para festivales, productores internacionales, coproducciones y colaboración teatral internacional.'
pubDate: '2026-06-29'
heroImage: './export-translated-play-script-international-submission.png'
heroImageAlt: 'Un guion teatral traducido y maquetado para una presentación teatral internacional'
tags: ['Traducción teatral', 'Traducción de guiones', 'Exportación de guion', 'Teatro internacional', 'SurtitleLive']
---

**Resumen principal:**  
Un guion teatral traducido solo resulta útil para una presentación internacional si es legible, está bien estructurado y tiene un formato claro. La traducción es el primer paso, pero los equipos teatrales también necesitan conservar los nombres de los personajes, los bloques de diálogo, las acotaciones, la estructura de escenas y las etiquetas de versión. SurtitleLive ayuda a los equipos a pasar de un guion original en Word a traducciones revisadas y, después, a exportar un guion traducido y maquetado que se puede compartir con festivales, productores extranjeros, traductores, dramaturgistas o socios de coproducción.

Muchos dramaturgos y compañías teatrales creen que la parte más difícil de enviar una obra al extranjero es la traducción.

Traducir es difícil, pero solo resuelve la mitad del problema.

Después de traducir las palabras, alguien todavía tiene que reconstruir el guion. Los nombres de los personajes deben mantenerse coherentes. El diálogo debe seguir siendo legible. Las acotaciones no deben confundirse con líneas habladas. Los cambios de escena deben conservarse. El archivo final debe parecer un guion teatral, no una salida copiada de una traducción automática.

Ese es el problema de flujo de trabajo que SurtitleLive está diseñado para reducir.

En lugar de tratar la traducción como un conjunto de textos desconectados, SurtitleLive mantiene la obra como un documento teatral estructurado. El equipo puede revisar las líneas traducidas, refinar el lenguaje y luego exportar un guion traducido y maquetado para lectores internacionales.

Para dramaturgos, productores, traductores y compañías teatrales que preparan envíos al extranjero, festivales, residencias, conversaciones de gira o coproducciones, esto puede convertir la traducción de un proceso desordenado de copiar y pegar en un flujo de producción más limpio.

## La traducción es solo el primer paso

Un guion teatral traducido no está terminado solo porque las palabras hayan pasado a otro idioma.

Un guion teatral tiene estructura:

- nombres de personajes
- diálogo
- acotaciones
- divisiones de actos y escenas
- notas de producción
- canciones o pasajes poéticos
- frases repetidas
- pausas, silencio y ritmo
- convenciones de formato que ayudan al lector a entender qué se dice y qué no

Cuando un guion se copia en una herramienta de traducción genérica, buena parte de esa estructura puede perderse.

El resultado puede contener texto traducido, pero no necesariamente un guion traducido utilizable.

Por ejemplo, una salida de traducción automática puede entregar un bloque largo de texto. Puede traducir los nombres de los personajes de manera inconsistente. Puede mezclar acotaciones con diálogo. Puede eliminar saltos de línea importantes. Puede producir algo que ayuda a comprender el sentido, pero que todavía deja horas de maquetación manual antes de poder enviar el archivo a otro teatro.

Para una presentación internacional, la presentación importa.

Un lector de festival, un productor extranjero, un dramaturgista o un socio de coproducción no deberían tener que reconstruir tu guion antes de leerlo. Necesitan un documento limpio que muestre claramente la estructura de la obra.

Por eso importa la etapa de exportación.

## Por qué un guion traducido y maquetado importa en el teatro internacional

Cuando envías una obra a otro país o región, el guion traducido suele convertirse en el primer puente entre tu trabajo y una nueva comunidad artística.

El lector quizá no conoce tu idioma, tu escena teatral, tu contexto cultural ni el estilo original de la puesta en escena. El guion traducido debe ayudarle a entender la obra con suficiente claridad como para imaginarla en el escenario.

Un guion traducido y maquetado puede ayudar en:

| Caso de uso | Por qué importa el formato |
| --- | --- |
| Presentación a festivales | Los lectores pueden seguir la historia, los personajes y el flujo de escenas sin confusión |
| Revisión por productores extranjeros | Los productores pueden evaluar si la obra encaja en su temporada, espacio o público |
| Conversación de coproducción | Los socios pueden discutir con más precisión las mismas escenas, líneas y personajes |
| Revisión de traducción | Traductores y dramaturgistas pueden comparar más fácilmente el texto fuente y el texto meta |
| Solicitud de residencia o subvención | Los jurados pueden leer la obra como un documento teatral coherente |
| Planificación de ensayos | Directores y actores pueden entender quién habla, cuándo y en qué contexto |
| Futuros sobretítulos o captions | El texto traducido estructurado puede adaptarse luego a texto de cues en vivo |

Un guion traducido y maquetado no es solo más bonito que una traducción en bruto. Es más útil.

Le dice al lector:

- quién habla
- qué es acotación
- dónde cambia la escena
- cómo fluye el diálogo
- si la traducción es un borrador, una versión de presentación o una versión revisada
- cómo se relaciona el texto traducido con el guion original

En el teatro internacional, esa claridad puede marcar la diferencia entre que una obra sea entendida o abandonada.

## El problema de copiar y pegar después de traducir

Muchos equipos todavía gestionan la traducción de guiones mediante un proceso manual:

1. Copiar una sección del guion original.
2. Pegarla en una herramienta de traducción.
3. Copiar la salida traducida.
4. Pegarla en un documento nuevo.
5. Reconstruir los nombres de los personajes.
6. Reconstruir los saltos de línea.
7. Corregir las acotaciones.
8. Reparar el formato.
9. Repetir hasta terminar el guion completo.

Esto funciona para unas pocas páginas.

Se vuelve doloroso para una obra completa.

También crea riesgos. El equipo puede eliminar una línea por accidente, duplicar otra, etiquetar mal a un personaje, perder una acotación o enviar una versión antigua después de que el guion haya cambiado.

El problema no es solo la calidad de la traducción. El problema es el control documental.

Si el guion fuente, las líneas traducidas, las revisiones y la exportación final viven en archivos separados, el equipo debe gestionar la coherencia manualmente. Eso se complica cuando participan varias personas: dramaturgo, traductora, director, dramaturgista, productora o socio extranjero.

SurtitleLive se basa en una idea distinta:

> Mantén el guion estructurado desde el principio, revisa las traducciones dentro de esa estructura y exporta la versión traducida desde el mismo flujo de trabajo.

## El flujo de SurtitleLive: del guion original a la exportación traducida y maquetada

SurtitleLive ofrece un flujo centrado en el guion para equipos teatrales que necesitan textos traducidos para uso internacional.

El proceso puede ser así.

### 1. Sube el guion original en Word

Comienza con el guion original, idealmente como un archivo Word `.docx` limpio.

Un guion en Word puede conservar señales importantes de maquetación teatral: saltos de párrafo, sangrías, etiquetas de personaje, cursivas y otros formatos que ayudan a distinguir diálogo de acotaciones.

SurtitleLive usa la estructura del guion subido como base del flujo de trabajo.

### 2. Revisa la estructura detectada del guion

Después de subirlo, el equipo revisa la estructura del guion.

Esto puede incluir:

- nombres de personajes o hablantes
- líneas de diálogo
- acotaciones
- divisiones de escenas o actos
- roles de personajes
- líneas que necesitan corrección manual

Este paso es importante porque la traducción es más fácil de gestionar cuando el sistema sabe qué es cada línea.

Una línea de personaje, una acotación y un encabezado no deberían tratarse igual.

### 3. Genera o introduce el texto traducido

Una vez estructurado el guion fuente, el equipo puede crear el texto traducido.

Según las necesidades de la producción, esto puede incluir:

- borradores de traducción asistida por IA
- aportes de traductores humanos
- borradores bilingües editados
- traducciones existentes pegadas línea por línea
- versiones revisadas por traductores
- borradores de trabajo específicos por idioma

Lo importante es que las traducciones sigan conectadas con las líneas del guion original.

Esto facilita la revisión. También hace que la exportación sea más limpia.

### 4. Revisa la traducción línea por línea

Antes de exportar, el texto traducido debe ser revisado por una persona.

Esto es especialmente importante en teatro, donde la traducción correcta no siempre es la más literal.

Los revisores pueden comprobar:

- voz del personaje
- ritmo
- subtexto
- referencias culturales
- chistes e modismos
- presión emocional
- longitud de línea
- claridad escénica
- coherencia de nombres y términos

SurtitleLive ayuda a mantener esta revisión dentro del flujo del guion, en vez de obligar al equipo a comparar documentos desconectados.

### 5. Elige la exportación del guion traducido

Después de revisar la traducción, el equipo puede exportar un guion traducido y maquetado.

Este es el paso clave para una presentación internacional.

En lugar de enviar una tabla de traducción en bruto o un documento copiado y desordenado, el equipo puede crear una versión legible del guion que preserve la estructura teatral.

Una exportación traducida y maquetada puede usarse para:

- presentaciones a festivales
- copias de lectura para productores extranjeros
- conversaciones de coproducción
- revisión de traductores o dramaturgistas
- planificación de ensayos
- comunicación con socios
- conversaciones iniciales de gira
- preparación futura de sobretítulos o captions

La exportación no es solo un archivo. Es un documento de entrega.

## Qué debe incluir un guion teatral traducido y maquetado

Un guion traducido útil debe hacer clara la experiencia de lectura.

Según el contexto de presentación o colaboración, puede incluir:

- título traducido
- título original, si es útil
- nombre del autor
- traductor o estado del borrador
- etiqueta de versión, como “English submission draft”
- lista de personajes
- estructura de actos y escenas
- nombres de hablantes
- diálogo traducido
- acotaciones traducidas
- espaciado consistente
- separación clara entre diálogo y acotaciones
- notas opcionales para términos culturalmente específicos
- información de contacto o derechos, cuando corresponda

Para una presentación internacional, las etiquetas de versión son especialmente importantes.

El lector debe saber si está leyendo:

- un primer borrador asistido por máquina
- una versión de presentación revisada por el dramaturgo
- un guion revisado por traductor
- una traducción literal de referencia
- un borrador de ensayo
- una adaptación para puesta en escena
- un borrador de sobretítulos o captions

Son documentos distintos. Una etiqueta clara protege la obra de malentendidos.

## Ejemplo: de un guion original en cantonés a un borrador de presentación en inglés

Imagina que un dramaturgo de Hong Kong quiere presentar una obra en cantonés a un festival teatral en Canadá.

El guion original está escrito en cantonés. La historia está ligada a la vida familiar de Hong Kong. El humor depende del ritmo, las relaciones y los detalles culturales. Sin embargo, el lector del festival necesita una versión en inglés antes de decidir si la obra encaja en el programa.

Un flujo práctico en SurtitleLive podría verse así:

1. El dramaturgo sube el guion original en Word en cantonés.
2. SurtitleLive ayuda a identificar hablantes, diálogo y acotaciones.
3. El equipo revisa la estructura del guion.
4. Se crea un borrador de traducción al inglés.
5. El dramaturgo o traductor edita el inglés línea por línea.
6. Se revisan cuidadosamente nombres de personajes, términos culturales y líneas emocionales.
7. El equipo exporta un borrador de presentación en inglés ya maquetado.
8. El archivo se envía al festival con una nota clara sobre el estado de la traducción.
9. Si el proyecto avanza, el mismo texto estructurado puede apoyar más adelante traducción de ensayo, sobretítulos, captions, proyección o visualización móvil para el público.

Este flujo no pretende que el software sustituya el juicio artístico.

Resuelve otro problema: ayuda al equipo a pasar del guion original a un documento traducido y revisado sin reconstruir manualmente el guion después de traducir.

## Ejemplo: de una obra española a un borrador alemán de coproducción

Ahora imagina una compañía española que prepara una conversación de coproducción con un teatro alemán.

El socio alemán todavía no necesita una traducción literaria final lista para publicación. Necesita un borrador de trabajo legible para entender la historia, discutir la escala de producción y decidir si vale la pena desarrollar el proyecto.

En esta situación, la exportación traducida no tiene que ser la versión final de puesta en escena.

Debe ser:

- legible
- estructurada
- claramente etiquetada
- fácil de discutir
- suficientemente cercana al original para una conversación artística
- editable para una revisión posterior de traducción

La compañía puede preparar el guion fuente en español, generar o introducir traducciones al alemán, revisar escenas clave y luego exportar un borrador de trabajo alemán maquetado para el socio.

Más tarde, si el proyecto entra en ensayo o producción, el texto traducido puede refinarse más.

La exportación ayuda a que la conversación empiece antes.

## Exportar no sustituye la revisión humana

Un guion traducido y maquetado es poderoso, pero no garantiza que la traducción sea artísticamente definitiva.

En un trabajo teatral serio, la revisión humana sigue siendo esencial.

Antes de usar el guion exportado para una presentación importante, publicación, licencia o producción, el equipo debería considerar una revisión por:

- el dramaturgo
- un traductor profesional
- un dramaturgista
- un director
- un hablante nativo del idioma meta
- un titular de derechos o editorial, si es necesario

SurtitleLive ayuda con la estructura, el flujo de traducción, la revisión y la exportación. Reduce la carga mecánica de reconstruir el guion traducido. No elimina la responsabilidad por el juicio artístico, legal o cultural.

Esa distinción importa.

El objetivo no es automatizar la traducción teatral.

El objetivo es hacer que el flujo de trabajo sea menos frágil.

## ¿Guion bilingüe o solo traducido?

En la colaboración internacional, los equipos suelen preguntar si deben enviar un guion bilingüe o solo la versión traducida.

La respuesta depende del lector.

Un lector de festival puede preferir una versión traducida limpia, especialmente si no lee el idioma original.

Un traductor o dramaturgista puede preferir una versión bilingüe para comparar líneas de origen y destino.

Un socio de coproducción puede querer ambas cosas: un borrador traducido limpio para la discusión general y una versión bilingüe de trabajo para revisión profunda.

Al preparar la exportación, pregunta:

- ¿Quién leerá este archivo?
- ¿Entiende el idioma original?
- ¿Está evaluando la historia o verificando la precisión de la traducción?
- ¿Es para presentación, ensayo, negociación o producción?
- ¿El documento debe ser fácil de leer, fácil de comparar o ambas cosas?

La mejor exportación es la que encaja con la siguiente conversación.

## Lista de verificación antes de exportar un guion traducido

Antes de exportar y enviar el guion traducido, revisa esta lista:

- ¿La versión del guion fuente es correcta?
- ¿Todas las líneas traducidas están completas?
- ¿Los nombres de los personajes son consistentes?
- ¿Las acotaciones están claramente separadas del diálogo?
- ¿Se conservan los cambios de acto y escena?
- ¿Una persona revisó las escenas emocionales clave?
- ¿Las referencias culturales se trataron de forma intencional?
- ¿Se revisaron chistes, modismos, canciones o líneas poéticas?
- ¿La exportación está etiquetada con el estado de versión correcto?
- ¿El documento es para presentación, colaboración, ensayo o puesta en escena?
- ¿El destinatario necesita una versión bilingüe o solo traducida?
- ¿Derechos, autoría y crédito de traducción están tratados correctamente?
- ¿El archivo es legible para alguien que nunca vio la obra original?

Una buena exportación traducida debe ayudar al lector a entrar rápidamente en la obra.

No debería obligarlo a resolver primero el formato.

## Del guion traducido a los sobretítulos en vivo

Una ventaja de mantener el guion estructurado es que el texto traducido puede servir para necesidades de producción posteriores.

Si la obra es aceptada por un festival, seleccionada para una lectura o desarrollada para una gira, el mismo material traducido puede convertirse luego en base para:

- sobretítulos en vivo
- captions de accesibilidad
- texto proyectado
- subtítulos móviles para el público
- opciones multilingües en el viewer
- referencias de traducción para ensayos
- listas de cues para operadores

Un guion traducido completo no es lo mismo que unos sobretítulos en vivo. Los sobretítulos normalmente deben ser más cortos, estar temporizados y adaptados para la lectura durante la función.

Pero un guion traducido estructurado es un mejor punto de partida que un documento de traducción suelto.

Significa que el equipo no tiene que empezar de nuevo.

## La traducción como puente hacia oportunidades internacionales

Para muchos creadores teatrales, la traducción es el primer paso hacia oportunidades internacionales.

Una obra no puede ser considerada por un lector extranjero si ese lector no puede entenderla. Un productor no puede discutir una coproducción si la historia está encerrada en un idioma que no lee. Un festival no puede programar una obra si el equipo no puede compartir una versión legible.

Pero la traducción por sí sola no basta.

El guion traducido debe llegar en una forma que respete la obra.

Debe mostrar al lector los personajes, el ritmo, la estructura y el mundo del trabajo. Debe facilitar la entrada al guion, no hacer más difícil descifrarlo.

Por eso importa la exportación con formato.

SurtitleLive ayuda a los equipos teatrales a ir más allá de la traducción en bruto. Les ayuda a preparar un guion traducido revisado, estructurado y maquetado que puede viajar entre idiomas, regiones y conversaciones artísticas.

## FAQ

### ¿Cómo exporto un guion teatral traducido?

Para exportar un guion teatral traducido, primero estructura el guion original, revisa o crea traducciones para cada línea, verifica nombres de personajes y acotaciones, y luego genera una versión traducida y maquetada para lectura, presentación o colaboración. SurtitleLive apoya este flujo centrado en el guion para que el documento exportado conserve la estructura teatral en lugar de convertirse en texto traducido en bruto.

### ¿Qué formato debe tener un guion traducido para una presentación internacional?

Un guion traducido para presentación internacional debe ser legible, estar claramente etiquetado y tener formato de guion teatral. Debe incluir nombres de personajes, diálogo, acotaciones, cambios de acto o escena y una etiqueta de versión como “English submission draft” o “working translation.”

### ¿Puede la traducción con IA mantener el formato de un guion teatral?

Las herramientas genéricas de traducción con IA pueden no conservar de forma fiable el formato teatral. Pueden traducir texto, pero perder etiquetas de hablantes, acotaciones o estructura de líneas. Un flujo centrado en el guion es más seguro porque la traducción permanece conectada a la estructura teatral original.

### ¿Por qué es mejor un guion traducido y maquetado que texto de traducción copiado?

Un guion traducido y maquetado es más fácil de leer para festivales, productores, traductores, dramaturgistas y colaboradores. Muestra quién habla, dónde cambian las escenas y qué es acotación. El texto traducido copiado suele exigir que el lector o el equipo reconstruyan manualmente el documento.

### ¿Puede SurtitleLive exportar un guion traducido?

SurtitleLive ayuda a los equipos a mantener las líneas del guion fuente y las líneas traducidas dentro de un flujo estructurado, y luego a exportar materiales maquetados para revisión, colaboración y preparación de producción. Esto reduce la necesidad de reconstruir manualmente un guion traducido después de traducir.

### ¿Debo enviar un guion bilingüe o solo la versión traducida?

Depende del lector. Un lector de festival puede preferir un guion limpio solo traducido. Un traductor, dramaturgista o socio de coproducción puede preferir una versión bilingüe para comparar. Si es posible, prepara la versión que mejor encaje con la próxima decisión que el destinatario debe tomar.

### ¿El guion traducido exportado puede convertirse después en sobretítulos en vivo?

Sí. Un guion traducido y maquetado puede convertirse en la base de sobretítulos o captions en vivo, pero normalmente necesitará edición adicional para temporización, longitud de línea, cueing y legibilidad durante la función.

### ¿Exportar un guion traducido significa que la traducción es final?

No. Exportar crea un documento utilizable, pero la traducción debe revisarse según su propósito. Un borrador de presentación, un borrador de ensayo, una versión revisada por traductor y una traducción final de producción pueden requerir distintos niveles de revisión.

## Prepara tu guion traducido para lectores internacionales

Si estás preparando una obra para presentación internacional, revisión por productores extranjeros, programación de festivales, conversación de coproducción o colaboración multilingüe, la traducción no debería terminar como un archivo de texto desordenado.

Debe convertirse en un guion teatral legible.

SurtitleLive ayuda a los equipos teatrales a subir guiones originales, revisar líneas traducidas y exportar guiones traducidos y maquetados que son más fáciles de compartir con lectores internacionales.

[Empieza a preparar tu guion traducido con SurtitleLive](https://surtitlelive.com/auth/register)