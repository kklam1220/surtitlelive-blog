---
title: 'Jak przygotować i wyeksportować sformatowany przetłumaczony dramat do zgłoszenia międzynarodowego'
description: 'Dowiedz się, jak przygotować, sprawdzić i wyeksportować przetłumaczony dramat w czytelnym formacie dla festiwali, zagranicznych producentów, koprodukcji i międzynarodowej współpracy teatralnej.'
pubDate: '2026-06-29'
heroImage: './export-translated-play-script-international-submission.png'
heroImageAlt: 'Sformatowany przetłumaczony dramat przygotowany do międzynarodowego zgłoszenia teatralnego'
tags: ['Tłumaczenie dramatu', 'Tłumaczenie teatralne', 'Eksport scenariusza', 'Teatr międzynarodowy', 'SurtitleLive']
---

**Najważniejsze w skrócie:**  
Przetłumaczony dramat jest przydatny przy zgłoszeniach międzynarodowych tylko wtedy, gdy jest czytelny, uporządkowany i jasno sformatowany. Tłumaczenie to pierwszy krok, ale zespół teatralny musi także zachować imiona postaci, bloki dialogu, didaskalia, strukturę scen i oznaczenia wersji. SurtitleLive pomaga przejść od oryginalnego pliku Word do sprawdzonych tłumaczeń, a następnie wyeksportować sformatowany przetłumaczony tekst, który można udostępnić festiwalom, producentom zagranicznym, tłumaczom, dramaturgom lub partnerom koprodukcyjnym.

Wielu dramatopisarzy i wiele zespołów teatralnych sądzi, że najtrudniejszą częścią wysyłania sztuki za granicę jest tłumaczenie.

Tłumaczenie jest trudne, ale rozwiązuje tylko połowę problemu.

Po przetłumaczeniu słów ktoś nadal musi odbudować tekst. Imiona postaci muszą pozostać spójne. Dialog musi być czytelny. Didaskalia nie mogą zostać pomylone z wypowiedziami postaci. Podziały scen muszą przetrwać. Końcowy plik powinien wyglądać jak dramat, a nie jak skopiowany wynik tłumaczenia maszynowego.

Właśnie ten problem workflow SurtitleLive ma zmniejszać.

Zamiast traktować tłumaczenie jako stos niepołączonych fragmentów, SurtitleLive zachowuje sztukę jako uporządkowany dokument teatralny. Zespół może sprawdzić przetłumaczone linie, dopracować język, a następnie wyeksportować sformatowany tekst dla czytelników międzynarodowych.

Dla dramatopisarzy, producentów, tłumaczy i zespołów przygotowujących zgłoszenia za granicę, festiwale, rezydencje, rozmowy o trasach lub koprodukcje może to zmienić tłumaczenie z chaotycznego procesu kopiuj-wklej w czystszy workflow produkcyjny.

## Tłumaczenie to dopiero pierwszy krok

Przetłumaczony dramat nie jest gotowy tylko dlatego, że słowa zostały przeniesione do innego języka.

Tekst teatralny ma strukturę:

- imiona postaci
- dialog
- didaskalia
- podziały na akty i sceny
- notatki produkcyjne
- piosenki lub fragmenty poetyckie
- powracające frazy
- pauzy, ciszę i rytm
- konwencje formatowania pomagające czytelnikowi zrozumieć, co jest mówione, a co nie

Kiedy tekst zostanie skopiowany do ogólnego narzędzia tłumaczeniowego, duża część tej struktury może zniknąć.

Rezultat może zawierać przetłumaczony tekst, ale nie być użytecznym przetłumaczonym dramatem.

Na przykład tłumaczenie maszynowe może dać długi blok tekstu. Może tłumaczyć imiona postaci niespójnie. Może połączyć didaskalia z dialogiem. Może usunąć ważne podziały wierszy. Może pomóc zrozumieć sens, ale nadal zostawić wiele godzin ręcznego formatowania, zanim plik będzie można wysłać do innego teatru.

Przy zgłoszeniu międzynarodowym sposób prezentacji ma znaczenie.

Czytelnik festiwalowy, zagraniczny producent, dramaturg lub partner koprodukcyjny nie powinien musieć rekonstruować tekstu, zanim zacznie go czytać. Potrzebuje czystego dokumentu, który wyraźnie pokazuje strukturę sztuki.

Dlatego etap eksportu jest ważny.

## Dlaczego sformatowany przetłumaczony tekst jest ważny w teatrze międzynarodowym

Gdy wysyłasz sztukę do innego kraju lub regionu, przetłumaczony tekst często staje się pierwszym mostem między twoją pracą a nową wspólnotą artystyczną.

Czytelnik może nie znać twojego języka, sceny teatralnej, kontekstu kulturowego ani pierwotnego stylu przedstawienia. Przetłumaczony tekst musi pomóc mu zrozumieć dzieło na tyle jasno, by potrafił wyobrazić je sobie na scenie.

Sformatowany przetłumaczony tekst pomaga w takich sytuacjach:

| Zastosowanie | Dlaczego formatowanie ma znaczenie |
| --- | --- |
| Zgłoszenie festiwalowe | Czytelnicy mogą śledzić historię, postaci i przebieg scen bez dezorientacji |
| Ocena producenta zagranicznego | Producent może ocenić, czy tekst pasuje do sezonu, miejsca lub publiczności |
| Rozmowa o koprodukcji | Partnerzy mogą precyzyjniej omawiać te same sceny, linie i postaci |
| Korekta tłumaczenia | Tłumacze i dramaturdzy mogą łatwiej porównywać tekst źródłowy i docelowy |
| Rezydencja lub grant | Komisja może czytać sztukę jako spójny dokument teatralny |
| Planowanie prób | Reżyser i aktorzy rozumieją, kto mówi, kiedy i w jakim kontekście |
| Przyszłe surtitles lub captions | Uporządkowany tekst tłumaczenia można później przekształcić w tekst cue na żywo |

Sformatowany przetłumaczony dramat nie jest tylko ładniejszy od surowego wyniku tłumaczenia. Jest bardziej użyteczny.

Pokazuje czytelnikowi:

- kto mówi
- co jest didaskalium
- gdzie zmienia się scena
- jak płynie dialog
- czy tłumaczenie jest szkicem, wersją zgłoszeniową czy wersją sprawdzoną
- jak tłumaczenie odnosi się do oryginalnego tekstu

W pracy międzynarodowej ta jasność może zdecydować, czy sztuka zostanie zrozumiana, czy odłożona.

## Problem kopiowania i wklejania po tłumaczeniu

Wiele zespołów wciąż tłumaczy dramaty ręcznie:

1. Kopiuje fragment oryginalnego tekstu.
2. Wkleja go do narzędzia tłumaczeniowego.
3. Kopiuje wynik tłumaczenia.
4. Wkleja go do nowego dokumentu.
5. Odtwarza imiona postaci.
6. Odtwarza podziały wierszy.
7. Poprawia didaskalia.
8. Naprawia formatowanie.
9. Powtarza, aż cały tekst jest gotowy.

Działa to przy kilku stronach.

Przy pełnowymiarowej sztuce staje się bolesne.

Tworzy też ryzyko. Zespół może przypadkowo zgubić linię, zdublować inną, źle oznaczyć mówiącego, utracić didaskalium lub wysłać starą wersję po zmianach w tekście.

Problemem nie jest tylko jakość tłumaczenia. Problemem jest kontrola dokumentu.

Jeśli tekst źródłowy, linie tłumaczenia, poprawki i końcowy eksport znajdują się w osobnych plikach, zespół musi ręcznie pilnować spójności. Jest to trudniejsze, gdy pracuje kilka osób: autor, tłumaczka, reżyser, dramaturg, producentka lub partner zagraniczny.

SurtitleLive opiera się na innej idei:

> Zachowaj strukturę tekstu od początku, sprawdzaj tłumaczenia wewnątrz tej struktury, a następnie eksportuj wersję tłumaczoną z tego samego workflow.

## Workflow SurtitleLive: od oryginalnego tekstu do sformatowanego eksportu tłumaczenia

SurtitleLive wspiera workflow oparty na tekście źródłowym dla zespołów teatralnych, które potrzebują tłumaczonych dramatów do użytku międzynarodowego.

Proces może wyglądać tak.

### 1. Prześlij oryginalny plik Word

Zacznij od oryginalnego tekstu, najlepiej jako czystego pliku Word `.docx`.

Plik Word może zachować ważne sygnały teatralnego układu: akapity, wcięcia, oznaczenia mówiących, kursywę i inne formatowanie pomagające odróżnić dialog od didaskaliów.

SurtitleLive wykorzystuje strukturę przesłanego tekstu jako podstawę workflow.

### 2. Sprawdź wykrytą strukturę tekstu

Po przesłaniu zespół sprawdza strukturę tekstu.

Może to obejmować:

- imiona mówiących lub postaci
- linie dialogu
- didaskalia
- podziały scen lub aktów
- role postaci
- linie wymagające ręcznej korekty

Ten krok jest ważny, bo tłumaczenie jest łatwiejsze do zarządzania, gdy system wie, czym jest każda linia.

Linia postaci, didaskalium i nagłówek nie powinny być traktowane tak samo.

### 3. Wygeneruj lub wprowadź tekst tłumaczenia

Gdy tekst źródłowy jest uporządkowany, zespół może tworzyć tłumaczenie.

W zależności od potrzeb produkcji może to obejmować:

- szkice tłumaczenia wspomagane AI
- pracę ludzkiego tłumacza
- edytowane szkice dwujęzyczne
- istniejące tłumaczenia wklejane linia po linii
- wersje sprawdzone przez tłumacza
- robocze szkice dla konkretnych języków

Najważniejsze jest to, że tłumaczenia pozostają połączone z liniami oryginału.

Ułatwia to korektę i sprawia, że eksport jest czystszy.

### 4. Sprawdź tłumaczenie linia po linii

Przed eksportem tekst tłumaczenia powinien zostać sprawdzony przez człowieka.

W teatrze jest to szczególnie ważne, bo właściwe tłumaczenie nie zawsze jest najbardziej dosłowne.

Osoby sprawdzające mogą ocenić:

- głos postaci
- rytm
- podtekst
- odniesienia kulturowe
- żarty i idiomy
- napięcie emocjonalne
- długość linii
- klarowność sceniczną
- spójność nazw i terminów

SurtitleLive pomaga utrzymać ten etap w jednym workflow tekstu, zamiast zmuszać zespół do porównywania oderwanych dokumentów.

### 5. Wybierz eksport przetłumaczonego tekstu

Po sprawdzeniu tłumaczenia zespół może wyeksportować sformatowany przetłumaczony dramat.

To kluczowy krok dla zgłoszenia międzynarodowego.

Zamiast wysyłać surową tabelę tłumaczenia albo nieuporządkowany dokument z kopiowania, zespół może stworzyć czytelną wersję tekstu zachowującą strukturę teatralną.

Sformatowany eksport tłumaczenia może służyć do:

- zgłoszeń festiwalowych
- kopii do czytania dla producentów zagranicznych
- rozmów o koprodukcji
- sprawdzenia przez tłumacza lub dramaturga
- planowania prób
- komunikacji z partnerami
- wstępnych rozmów o trasie
- późniejszego przygotowania surtitles lub captions

Eksport nie jest tylko plikiem. To dokument przekazania.

## Co powinien zawierać sformatowany przetłumaczony dramat?

Użyteczny przetłumaczony dramat powinien ułatwiać czytanie.

W zależności od kontekstu może zawierać:

- tytuł w tłumaczeniu
- tytuł oryginalny, jeśli to przydatne
- nazwisko autora
- informację o tłumaczu lub statusie szkicu
- etykietę wersji, np. „English submission draft”
- listę postaci
- strukturę aktów i scen
- imiona mówiących
- przetłumaczony dialog
- przetłumaczone didaskalia
- spójne odstępy
- wyraźne oddzielenie dialogu od wskazówek
- opcjonalne noty do terminów kulturowych
- informacje kontaktowe lub prawne, jeśli potrzebne

Przy zgłoszeniu międzynarodowym etykiety wersji są szczególnie ważne.

Czytelnik powinien wiedzieć, czy czyta:

- pierwszy szkic wspomagany maszynowo
- szkic zgłoszeniowy sprawdzony przez autora
- tekst sprawdzony przez tłumacza
- dosłowne tłumaczenie referencyjne
- szkic prób
- adaptację sceniczną
- szkic surtitles lub captions

To różne typy dokumentów. Jasne oznaczenie chroni dzieło przed niezrozumieniem.

## Przykład: z kantońskiego oryginału do angielskiego szkicu zgłoszeniowego

Wyobraźmy sobie dramatopisarza z Hongkongu, który chce zgłosić sztukę po kantońsku na festiwal teatralny w Kanadzie.

Oryginał jest napisany po kantońsku. Historia jest mocno związana z życiem rodzinnym w Hongkongu. Humor zależy od rytmu, relacji i szczegółu kulturowego. Czytelnik festiwalowy potrzebuje jednak wersji angielskiej, zanim zdecyduje, czy tekst pasuje do programu.

Praktyczny workflow w SurtitleLive może wyglądać tak:

1. Autor przesyła oryginalny plik Word po kantońsku.
2. SurtitleLive pomaga rozpoznać mówiących, dialog i didaskalia.
3. Zespół sprawdza strukturę tekstu.
4. Powstaje szkic tłumaczenia na angielski.
5. Autor lub tłumacz poprawia angielski linia po linii.
6. Imiona postaci, terminy kulturowe i linie emocjonalne są dokładnie sprawdzane.
7. Zespół eksportuje sformatowany angielski szkic zgłoszeniowy.
8. Plik trafia do festiwalu z jasną informacją o statusie tłumaczenia.
9. Jeśli projekt ruszy dalej, ten sam uporządkowany tekst może później wspierać tłumaczenie prób, surtitles, captions, projekcję lub mobilny widok dla publiczności.

Ten workflow nie udaje, że oprogramowanie zastępuje osąd artystyczny.

Rozwiązuje inny problem: pomaga przejść od tekstu oryginalnego do sprawdzonego dokumentu tłumaczonego bez ręcznego odbudowywania tekstu po tłumaczeniu.

## Przykład: z hiszpańskiej sztuki do niemieckiego szkicu koprodukcyjnego

Wyobraźmy sobie teraz hiszpańską kompanię przygotowującą rozmowę koprodukcyjną z niemieckim teatrem.

Niemiecki partner nie potrzebuje jeszcze finalnego literackiego przekładu do publikacji. Potrzebuje czytelnego szkicu roboczego, aby zrozumieć historię, omówić skalę produkcji i zdecydować, czy projekt warto rozwijać.

W tej sytuacji eksport tłumaczenia nie musi być ostateczną wersją sceniczną.

Powinien być:

- czytelny
- uporządkowany
- jasno oznaczony
- łatwy do omówienia
- wystarczająco bliski oryginałowi do rozmowy artystycznej
- możliwy do późniejszej redakcji

Kompania może przygotować hiszpański tekst źródłowy, wygenerować lub wprowadzić tłumaczenie niemieckie, sprawdzić kluczowe sceny, a następnie wyeksportować sformatowany niemiecki szkic roboczy dla partnera.

Później, jeśli projekt przejdzie do prób lub produkcji, tłumaczenie można dalej dopracować.

Eksport pomaga rozpocząć rozmowę wcześniej.

## Eksport nie zastępuje ludzkiej korekty

Sformatowany przetłumaczony tekst jest potężnym narzędziem, ale nie gwarantuje, że tłumaczenie jest artystycznie ostateczne.

W poważnej pracy teatralnej ludzka korekta nadal ma znaczenie.

Przed użyciem eksportu do ważnego zgłoszenia, publikacji, licencji lub produkcji zespół powinien rozważyć sprawdzenie przez:

- autora
- profesjonalnego tłumacza
- dramaturga
- reżysera
- native speakera języka docelowego
- właściciela praw lub wydawcę, jeśli to potrzebne

SurtitleLive pomaga ze strukturą, workflow tłumaczenia, korektą i eksportem. Zmniejsza mechaniczny ciężar odbudowywania tekstu tłumaczonego. Nie usuwa odpowiedzialności za osąd artystyczny, prawny ani kulturowy.

To rozróżnienie jest ważne.

Celem nie jest automatyzacja tłumaczenia teatralnego.

Celem jest mniej kruchy workflow.

## Tekst dwujęzyczny czy tylko tłumaczenie?

W międzynarodowej współpracy zespoły często pytają, czy wysłać tekst dwujęzyczny, czy tylko tłumaczenie.

Odpowiedź zależy od czytelnika.

Czytelnik festiwalowy może preferować czystą wersję tylko w tłumaczeniu, zwłaszcza jeśli nie czyta języka źródłowego.

Tłumacz lub dramaturg może preferować wersję dwujęzyczną, aby porównywać linie oryginału i przekładu.

Partner koprodukcyjny może chcieć obu: czystego szkicu do ogólnej rozmowy i dwujęzycznej wersji roboczej do głębszej analizy.

Przygotowując eksport, zapytaj:

- Kto będzie czytał ten plik?
- Czy zna język oryginału?
- Czy ocenia historię, czy dokładność tłumaczenia?
- Czy to dokument do zgłoszenia, prób, negocjacji czy produkcji?
- Czy dokument ma być łatwy do czytania, łatwy do porównania, czy jedno i drugie?

Najlepszy eksport to ten, który pasuje do następnej rozmowy.

## Lista kontrolna przed eksportem przetłumaczonego dramatu

Przed eksportem i wysłaniem tekstu sprawdź:

- Czy wersja tekstu źródłowego jest właściwa?
- Czy wszystkie linie tłumaczenia są kompletne?
- Czy imiona postaci są spójne?
- Czy didaskalia są wyraźnie oddzielone od dialogu?
- Czy zachowano podziały aktów i scen?
- Czy człowiek sprawdził kluczowe sceny emocjonalne?
- Czy odniesienia kulturowe potraktowano świadomie?
- Czy sprawdzono żarty, idiomy, piosenki lub linie poetyckie?
- Czy eksport ma właściwe oznaczenie wersji?
- Czy dokument służy do zgłoszenia, współpracy, prób czy przedstawienia?
- Czy odbiorca potrzebuje wersji dwujęzycznej czy tylko tłumaczenia?
- Czy prawa, autorstwo i kredyt tłumaczeniowy są poprawnie opisane?
- Czy plik jest czytelny dla osoby, która nigdy nie widziała oryginalnej sztuki?

Dobry eksport tłumaczenia powinien pomóc czytelnikowi szybko wejść w sztukę.

Nie powinien zmuszać go do naprawiania formatowania.

## Od przetłumaczonego tekstu do live surtitles

Jedną z zalet utrzymywania struktury tekstu jest to, że tłumaczenie może później wspierać potrzeby produkcyjne.

Jeśli sztuka zostanie przyjęta przez festiwal, wybrana do czytania lub rozwijana na trasę, ten sam materiał może stać się podstawą dla:

- live surtitles
- accessibility captions
- tekstu projekcyjnego
- napisów mobilnych dla publiczności
- wielojęzycznych opcji viewer
- referencji tłumaczeniowych na próby
- list cue dla operatorów

Pełny przetłumaczony dramat nie jest tym samym co live surtitles. Surtitles zwykle muszą być krótsze, zsynchronizowane i dostosowane do czytania podczas przedstawienia.

Ale uporządkowany przetłumaczony tekst jest lepszym punktem wyjścia niż luźny dokument tłumaczenia.

Zespół nie musi zaczynać od nowa.

## Tłumaczenie jako most do międzynarodowych szans

Dla wielu twórców teatralnych tłumaczenie jest pierwszym krokiem do międzynarodowych możliwości.

Sztuka nie może zostać rozważona przez zagranicznego czytelnika, jeśli ten jej nie rozumie. Producent nie może rozmawiać o koprodukcji, jeśli historia jest zamknięta w języku, którego nie czyta. Festiwal nie może zaprogramować pracy, jeśli zespół nie może udostępnić czytelnej wersji.

Ale samo tłumaczenie nie wystarczy.

Przetłumaczony tekst musi dotrzeć w formie, która szanuje sztukę.

Powinien pokazywać postaci, rytm, strukturę i świat utworu. Powinien ułatwiać wejście w tekst, a nie utrudniać jego rozszyfrowanie.

Dlatego sformatowany eksport ma znaczenie.

SurtitleLive pomaga zespołom teatralnym wyjść poza surowe tłumaczenie. Pomaga przygotować sprawdzony, uporządkowany i sformatowany tekst, który może podróżować między językami, regionami i rozmowami artystycznymi.

## FAQ

### Jak wyeksportować przetłumaczony dramat?

Aby wyeksportować przetłumaczony dramat, najpierw uporządkuj oryginalny tekst, sprawdź lub utwórz tłumaczenie każdej linii, skontroluj imiona mówiących i didaskalia, a następnie wygeneruj sformatowaną wersję do czytania, zgłoszenia lub współpracy. SurtitleLive wspiera taki script-first workflow, dzięki czemu eksport zachowuje strukturę teatralną zamiast stawać się surowym tekstem tłumaczenia.

### Jaki format powinien mieć przetłumaczony tekst do zgłoszenia międzynarodowego?

Powinien być czytelny, jasno oznaczony i sformatowany jak dramat. Powinien zawierać imiona postaci, dialog, didaskalia, podziały aktów lub scen oraz etykietę wersji, na przykład „English submission draft” albo „working translation”.

### Czy tłumaczenie AI potrafi zachować format dramatu?

Ogólne narzędzia AI nie zawsze niezawodnie zachowują format dramatu. Mogą przetłumaczyć tekst, ale zgubić oznaczenia mówiących, didaskalia lub strukturę linii. Workflow oparty na strukturze tekstu jest bezpieczniejszy, ponieważ tłumaczenie pozostaje połączone z pierwotną strukturą teatralną.

### Dlaczego sformatowany przetłumaczony dramat jest lepszy niż skopiowany tekst tłumaczenia?

Jest łatwiejszy do czytania dla festiwali, producentów, tłumaczy, dramaturgów i partnerów. Pokazuje, kto mówi, gdzie zmieniają się sceny i co jest didaskalium. Skopiowany tekst tłumaczenia często wymaga ręcznego odbudowania dokumentu.

### Czy SurtitleLive może eksportować przetłumaczony tekst?

SurtitleLive pomaga zespołom utrzymać linie oryginału i tłumaczenia w uporządkowanym workflow, a następnie eksportować sformatowane materiały do korekty, współpracy i przygotowania produkcji. Zmniejsza to potrzebę ręcznego odbudowywania tłumaczonego tekstu po tłumaczeniu.

### Czy wysłać tekst dwujęzyczny czy tylko tłumaczenie?

To zależy od czytelnika. Czytelnik festiwalowy może preferować czystą wersję tłumaczoną. Tłumacz, dramaturg lub partner koprodukcyjny może woleć wersję dwujęzyczną do porównania. Jeśli to możliwe, przygotuj wersję najlepiej pasującą do kolejnej decyzji odbiorcy.

### Czy wyeksportowany przetłumaczony tekst może później stać się live surtitles?

Tak. Sformatowany przetłumaczony tekst może stać się podstawą live surtitles lub captions, ale zwykle wymaga dodatkowej edycji pod kątem czasu, długości linii, cueing i czytelności podczas przedstawienia.

### Czy eksport oznacza, że tłumaczenie jest ostateczne?

Nie. Eksport tworzy użyteczny dokument, ale tłumaczenie nadal powinno być sprawdzone zgodnie z celem. Szkic zgłoszeniowy, szkic prób, wersja sprawdzona przez tłumacza i finalne tłumaczenie sceniczne mogą wymagać różnych poziomów korekty.

## Przygotuj przetłumaczony tekst dla czytelników międzynarodowych

Jeśli przygotowujesz sztukę do zgłoszenia międzynarodowego, oceny producenta zagranicznego, programu festiwalowego, rozmowy koprodukcyjnej lub współpracy wielojęzycznej, tłumaczenie nie powinno kończyć się jako chaotyczny plik tekstowy.

Powinno stać się czytelnym tekstem teatralnym.

SurtitleLive pomaga zespołom teatralnym przesyłać oryginalne teksty, sprawdzać linie tłumaczenia i eksportować sformatowane przetłumaczone dramaty, które łatwiej udostępnić międzynarodowym czytelnikom.

[Zacznij przygotowywać przetłumaczony tekst w SurtitleLive](https://surtitlelive.com/auth/register)